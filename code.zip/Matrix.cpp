#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <memory.h>
#include <assert.h>
#include <string.h>

using namespace std;

const int MAX_MATRIX_SIZE=100;
const double MIN_DOUBLE=1.0E-200;

bool Inverse(double *pdInv, double* pA, int iDimension)
{
	unsigned uSize=iDimension*2*iDimension;
	double* pdB=new double[uSize];
	assert(pdB!=NULL);
	memset(pdB,0,uSize*sizeof(double));

	int i=0,j=0,k=0,l=0,m=0;

	for(int i=0; i<iDimension; i++)
	{
	    l=i*2*iDimension;
		for(int j=0; j<iDimension; j++)
		{
			pdB[l+j]=pA[i*iDimension+j];
		}
		pdB[l+iDimension+i]=1;
	}
		
	//for(int i=0; i<iDimension-1; i++)
	for(int i=0; i<iDimension; i++)
	{
		// find a row with b[i][i]!=0;
		l=i*2*iDimension;
		//if(pdB[l+i]==0)
		if(fabs(pdB[l+i])<MIN_DOUBLE)
		{
			bool bFound=false;
			for(int j=i+1;j<iDimension && !bFound; j++)
			{
				m=j*2*iDimension;
				//if(pdB[m+j]!=0)
				if(fabs(pdB[m+j])>MIN_DOUBLE)
				{
					bFound=true;
					// exchange row i and row j;
					for(k=i;k<2*iDimension;k++)
					{
						double temp=pdB[l+k];
						pdB[l+k]=pdB[m+k];
						pdB[m+k]=temp;
					}
				}
			}
			if(!bFound)
			{
				delete []pdB;
				//assert(false);
				return(false);
			}
		}

		
		for(int j=2*iDimension-1; j>=i; j--)
			pdB[l+j]/=pdB[l+i];

		for(int j=i+1; j<iDimension; j++)
		{
			// row j - dM * row i
			m=j*2*iDimension;
			double dM=pdB[m+i]/pdB[l+i];          // multiplier for row j;
			for(k=i; k<2*iDimension; k++)
			{
				pdB[m+k]-=dM*pdB[l+k];
			}
		}
	}

/*	l=i*2*iDimension;
	for(int j=2*iDimension-1;j>=i;j--)
		pdB[l+j]/=pdB[l+i];
*/
	for(int j=iDimension-2; j>=0; j--)
	{
		m=j*2*iDimension;
		for(k=2*iDimension-1; k>j; k--)
		{
			for(int i=iDimension-1; i>j; i--)
			{
				l=i*2*iDimension;
				// row j-dB[j][i]*row i;
				pdB[m+k]-=pdB[m+i]*pdB[l+k];
			}
		}
	}

	// assign the value of the inverse matrix;
	for(int i=0; i<iDimension; i++)
	{
		for(int j=0; j<iDimension; j++)
			pdInv[i*iDimension+j]=pdB[i*2*iDimension+iDimension+j];
	}

	delete []pdB;

	return(true);
}

void Multiply(double* pdD, double* pdA, double* pdB,int m, int n, int r)
{
	//double *pdC=new double[m*r];
	//assert(pdC!=NULL);
	//memset(pdC,0,m*r*sizeof(double));
	double pdC[1000];
	memset(pdC,0,1000*sizeof(double));
	assert(m*r<1000);


	for(int i=0; i<m; i++)
	{
		for(int j=0; j<r; j++)
		{
			for(int k=0; k<n; k++)
				pdC[i*r+j]+=pdA[i*n+k]*pdB[k*r+j];	
		}
	}

	memcpy(pdD,pdC,m*r*sizeof(double));
	//delete []pdC;
}

// pdA: mxn, pdB: rxn;
// A*B^T
void MultiplyT(double* pdD, double* pdA, double* pdB,int m, int n, int r)
{
	//double *pdC=new double[m*r];
	//assert(pdC!=NULL);
	//memset(pdC,0,m*r*sizeof(double));
	double pdC[1000];
	memset(pdC,0,1000*sizeof(double));
	assert(m*r<1000);

	for(int i=0; i<m; i++)
	{
		for(int j=0; j<r; j++)
		{
			for(int k=0; k<n; k++)
				pdC[i*r+j]+=pdA[i*n+k]*pdB[j*n+k];	
		}
	}

	memcpy(pdD,pdC,m*r*sizeof(double));
	//delete []pdC;
}

// pdA: nxm, pdB: nxr;
// A^T*B
void TMultiply(double* pdD, double* pdA, double* pdB,int m, int n, int r)
{
	double *pdC=new double[m*r];
	memset(pdC,0,m*r*sizeof(double));

	for(int i=0; i<m; i++)
	{
		for(int j=0; j<r; j++)
		{
			for(int k=0; k<n; k++)
				pdC[i*r+j]+=pdA[k*m+i]*pdB[k*r+j];	
		}
	}

	memcpy(pdD,pdC,m*r*sizeof(double));
	delete []pdC;
}

void MultiplyScalar(double* pdD, double* pdA, double dB, int m, int n)
{
	int k=0;
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			pdD[k] = pdA[k]*dB;
			k++;
		}
	}
}


void SumMatrix(double* AB, double* A, double* B, int m, int n)
{
	int k=0;
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			AB[k]=A[k]+B[k];
			k++;
		}
	}
}

void SumMatrix(double* AB, double* A, const double* B, int m, int n)
{
	int k = 0;
	for (int i = 0; i<m; i++)
	{
		for (int j = 0; j<n; j++)
		{
			AB[k] = A[k] + B[k];
			k++;
		}
	}
}

void SubtractMatrix(double* AB, double* A, double* B, int m, int n)
{
	int k=0;
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			AB[k]=A[k]-B[k];
			k++;
		}
	}
}






