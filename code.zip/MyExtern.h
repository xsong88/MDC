extern void CCox();
extern void DeCCox();

extern void Initiate(FILE* fSurvival,FILE* fLongitudinal);
extern void SetCoefficentOfProportionalHazardModel(double *dGamma);
extern void SetObservationTime(double* dTij);
extern void SetVarianceOfE(double* dSigmaSq);
extern void SetStartParametersForInteration(double *dGamma);

extern double GetSigmaHat();

extern bool ProportionalHazardRegression(double* pdGamma, double* pdSeGamma, EMethod eMethod, bool bComputeSE, double h);

extern double GetSmoothParm( EMethod eMethod, double dAveObsQ, int& iDeathNumber, int& iRiskNumber, double& dVar_t0, double& dVar_tm, double* dGamma);

extern void SetStartParametersForIteration(double *dGamma);

extern void SortAllDeathTime();

extern double GetCensoringRate();
extern void SetInitiateParameters();

extern double CrossValidationForBandWidth(int& iSelectedConstant, bool bCV, double dAveObsQ, int& iDeathNumber, int& iRiskNumber, double& dVar_t0, double& dVar_tm);

extern void InitiateForIter();
extern double GetAveObs();
extern double GetLogPartialLikelihood(double* pdGamma, EMethod eMethod);

extern void GetG(EMethod eMethod, double h, bool bSmooth);

