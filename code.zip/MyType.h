// Type.h: Definition for some data structure
//
//////////////////////////////////////////////////////////////////////

#if !defined(_Type_h572075475205640)
	#define _Type_h572075475205640
#endif

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define TIMEDEP_COV
#define TRUEDATA
//#define TwoCov
//#define TrichotomizeX
//#define CROSS_VALIDATION
//#define QUADRATIC_X

///////////////////////////////////////////////////////////
// Information of the data
const int iTrueTimeIndCov = 0;

const char SURVFILE[] = "ExampleSurv.dat";
const char LONGFILE[] = "ExampleLong.dat";

const int iSubjectNumber = 500;		// # of subjects in the data set
const int iDeathTime = 500;			// maximum number of death times
const int iObservations = 50;		// maximum number of observations

const double CutOff_X[] = { log10(350), DBL_MAX };   // cutoff points for discritizing X(t)

/////////////////////////////////////////////////////////


const double C_Smooth = 0.18;
const int iRiskSet = 5;    

const int CV_FOLDS=5;				// # folds for cross-validation
const double PI=atan(1.)*4.;

const double dMaxObserveTime=1.0e20;

const int iTrueTimeDepCov=1;      
#ifdef TrichotomizeX
	const int iTimeDepCov=2;    // # gamma
#else
	const int iTimeDepCov = 1;    // # gamma
#endif


const int iTimeIndCov= iTrueTimeIndCov;   //  eta
const int iCov=iTimeDepCov+iTimeIndCov;          // # gamma+eta
const int iParm=iCov+iTrueTimeDepCov;			//  # gamma+eta+sigma

const int DIM_TIMEDEP=(iTimeDepCov>0)?iTimeDepCov:1;     // use this to avoid 0-dimensional arrays
const int DIM_TIMEIND=(iTimeIndCov>0)?iTimeIndCov:1;     // use this to avoid 0-dimensional arrays
const int PARM_SIGMA=(iTimeDepCov>0)?iTrueTimeDepCov:1;  // use this to avoid 0-dimensional arrays

#ifdef TIMEDEP_COV
	#ifndef QUADRATIC_X
		const int Order_MixedModel=1;
	#else
		const int Order_MixedModel = 2;
	#endif
#else
	const int Order_MixedModel=0;
#endif

const int Dim_MixedModel=Order_MixedModel+1;
const int Dim_MixedModel2 = Dim_MixedModel * Dim_MixedModel;

const int iParmRegCal = iParm + Dim_MixedModel * (iTrueTimeIndCov + 1) + (1 + Dim_MixedModel) * Dim_MixedModel / 2; // gamma+eta+sigma+alpha.mean+alpha.var;

const double CutOffTime=1e20;
const int iCovUsed=0;


const int iNumberOfMethod=5;
const int iMaxNumberOfMethod = 10;
const int iMaxSimulation=1000;
const int iStartMethod=1;

enum EMethod
{
	Ideal,
	Ideal_Approx,			 // smoothed ideal
    Naive,
	SCS,					 // smoothed corrected score
	RC,					     // regression calibration
	RRC                      //risk-set regression calibration
};

struct CMyPoint
{
	double a[Dim_MixedModel];   
};

#if !defined(CROSS_VALIDATION)
	const int SmoothParm_Iter_CV = 0;  //
#else
	const int SmoothParm_Iter_CV = 15;  //  Numbere of c's to search from the starting value
#endif

const double SmoothParm_Start = 0.1;  // Start c for cross validation
const double SmoothParm_Inc = 0.1;	  // increment of c

	



