//////////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <math.h>
#include <memory.h>
#include <assert.h>
#include <string.h>
#include <imsl.h>
#include <imsls.h>
#include "MyType.h"
#include "Cox.h"
#include "MatrixExtern.h"

using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction

int countinclude=0;
void CCox()
{
	m_iSubjectNumber = iSubjectNumber;

    m_lSeed = 10;

	memset(m_dTrueGamma,0,iCov*sizeof(double));
	memset(m_dStartGamma,0,iCov*sizeof(double));

	
	memset(m_dSigmaSq,0,PARM_SIGMA*sizeof(double));
	memset(m_dSigmaSqHat,0,PARM_SIGMA*sizeof(double));
	m_iNumberOfDeathTime = 0;
	m_iNumberOfDeathTime_Naive = 0;
	m_iNumberOfSubject_AtRisk = 0;
	m_dMedianT = 0;

	m_dMixedSD=0;
	m_dMixedMean=0;

	m_dTij=new double[iObservations];
	memset(m_dTij,0,iObservations*sizeof(double));
		
	m_pdV=new double[iSubjectNumber];
	memset(m_pdV,0,iSubjectNumber*sizeof(double));
	m_pdT = new double[iSubjectNumber];
	memset(m_pdT, 0, iSubjectNumber * sizeof(double));
	m_pdC = new double[iSubjectNumber];
	memset(m_pdC, 0, iSubjectNumber*sizeof(double));
	m_piDelta=new int[iSubjectNumber];
	memset(m_piDelta,0,iSubjectNumber*sizeof(int));

	m_pdZ = new double[iSubjectNumber][DIM_TIMEIND];
	memset(m_pdZ,0,iSubjectNumber*DIM_TIMEIND*sizeof(double));

	m_pdSortedDeathTime=new double[iSubjectNumber];
	memset(m_pdSortedDeathTime,0,iSubjectNumber*sizeof(double));
	
	m_pcAlpha=new CMyPoint[iSubjectNumber][DIM_TIMEDEP];
	memset(m_pcAlpha,0,iSubjectNumber* DIM_TIMEDEP *sizeof(CMyPoint));

	m_pdAlpha_Var = new double[iSubjectNumber][DIM_TIMEDEP][Dim_MixedModel*Dim_MixedModel];
	memset(m_pdAlpha_Var, 0, iSubjectNumber* DIM_TIMEDEP *Dim_MixedModel*Dim_MixedModel*sizeof(double));

	memset(m_Alpha_Var_Hat, 0, iRiskSet* DIM_TIMEDEP *Dim_MixedModel * Dim_MixedModel * sizeof(double));
	memset(m_Alpha_E_Hat, 0, iRiskSet* (DIM_TIMEDEP+1) * DIM_TIMEDEP *Dim_MixedModel * sizeof(double));

	m_pdG=new double[iSubjectNumber][iDeathTime][iCov];
	assert(m_pdG!=NULL);
	memset(m_pdG, 0, iSubjectNumber* iDeathTime *iCov*sizeof(double));

	m_pdG_der = new double[iSubjectNumber][iDeathTime][iCov];
	assert(m_pdG_der != NULL);
	memset(m_pdG_der, 0, iSubjectNumber * iDeathTime * iCov * sizeof(double));

	m_pdG_der2 = new double[iSubjectNumber][iDeathTime][iCov];
	assert(m_pdG_der2 != NULL);
	memset(m_pdG_der2, 0, iSubjectNumber * iDeathTime * iCov * sizeof(double));
	
	m_piNumberOfDeathBeforeEvent=new int[iSubjectNumber];
	assert(m_piNumberOfDeathBeforeEvent!=NULL);
	memset(m_piNumberOfDeathBeforeEvent, 0, iSubjectNumber*sizeof(int));

	m_pdObservedCovariate=new double[iSubjectNumber][DIM_TIMEDEP][iObservations];
	assert(m_pdObservedCovariate!=NULL);
	memset(m_pdObservedCovariate, 0, iSubjectNumber*DIM_TIMEDEP*iObservations*sizeof(double));

	m_pdObservedTime=new double[iSubjectNumber][iObservations];
	assert(m_pdObservedTime!=NULL);

	double dMaxObserveTimePlusOne=dMaxObserveTime+1;
	for(int i=0; i<iSubjectNumber; i++)
	{
		for(int j=0; j<iObservations;j++)
				m_pdObservedTime[i][j]=dMaxObserveTimePlusOne;
	}

	m_pdTheta=new double[iSubjectNumber][iDeathTime][DIM_TIMEDEP*DIM_TIMEDEP];
    assert(m_pdTheta!=NULL);
	memset(m_pdTheta, 0, iSubjectNumber*iDeathTime*DIM_TIMEDEP*DIM_TIMEDEP*sizeof(double));

	m_piIncludedDeathTime=new int[iSubjectNumber];
	assert(m_piIncludedDeathTime!=NULL);
	memset(m_piIncludedDeathTime, 0, iSubjectNumber*sizeof(int));


	m_pdE0=new double[iDeathTime];
	assert(m_pdE0!=NULL);
	memset(m_pdE0, 0, iDeathTime*sizeof(double));

	m_pdE0_Tau=new double[iDeathTime][iParmRegCal];
	assert(m_pdE0_Tau!=NULL);
	memset(m_pdE0_Tau, 0, iDeathTime* iParmRegCal *sizeof(double));

	m_pdE1=new double[iDeathTime][iCov];
	assert(m_pdE1!=NULL);
	memset(m_pdE1, 0, iDeathTime*iCov*sizeof(double));

	m_pdE1_Tau=new double[iDeathTime][iCov][iParmRegCal];
	assert(m_pdE1_Tau!=NULL);
	memset(m_pdE1_Tau, 0, iDeathTime*iCov* iParmRegCal *sizeof(double));

	m_pdSSResidual=new double[iSubjectNumber][DIM_TIMEDEP];
	assert(m_pdSSResidual!=NULL);
	memset(m_pdSSResidual, 0, iSubjectNumber*DIM_TIMEDEP*sizeof(double));

	m_piCountOfObs=new int[iSubjectNumber][DIM_TIMEDEP];
	assert(m_piCountOfObs);
	memset(m_piCountOfObs, 0, iSubjectNumber*DIM_TIMEDEP*sizeof(int));
	
	m_piNumberOfDeathAtDeathTime=new int[iSubjectNumber];
	memset(m_piNumberOfDeathAtDeathTime,0,iSubjectNumber*sizeof(int));

	m_piMaxCountOfObs=new int[iSubjectNumber];
	memset(m_piMaxCountOfObs,0,iSubjectNumber*sizeof(int));

	countinclude=0;
	memset(m_dfCov,0,PARM_SIGMA*sizeof(double));

	m_piSubjectFailedAtDeathTime=new int[iSubjectNumber];
	memset(m_piSubjectFailedAtDeathTime,0,iSubjectNumber*sizeof(int));

	m_K=0;
	m_numOfParmInPoly=1;

	m_D=NULL; 
	m_R[0]=1;
	m_R[1]=0;
	m_R[2]=1;
	m_mu[0]=m_mu[1]=0;

	m_pdTotalCumHazard=new double[iSubjectNumber*iMaxSimulation][iNumberOfMethod];
	memset(m_pdTotalCumHazard,0,iSubjectNumber*iMaxSimulation*iNumberOfMethod*sizeof(double));
	m_pdAllDeathTimes=new double[iSubjectNumber*iMaxSimulation];
	memset(m_pdAllDeathTimes,0,iSubjectNumber*iMaxSimulation*sizeof(double));
	m_iAllDeathNumber=0;


	imsls_random_seed_set(m_lSeed);    // seed for simulation

	memset(m_dmatChol, 0, (iTrueTimeDepCov*Dim_MixedModel + iTrueTimeIndCov)*(iTrueTimeDepCov*Dim_MixedModel + iTrueTimeIndCov)*sizeof(double));
	memset(m_dmatChol_b, 0, (iTrueTimeDepCov*Dim_MixedModel + iTrueTimeIndCov)*(iTrueTimeDepCov*Dim_MixedModel + iTrueTimeIndCov)*sizeof(double));
	
	m_cenRate = 0;
	m_aveObs = 0;

	memset(m_qt,0,19*sizeof(double));
	memset(m_qt_total,0,19*sizeof(double));
	memset(m_qtRisk, 0, (iRiskSet+1) * sizeof(double));
	memset(m_maxVar, 0, DIM_TIMEDEP *sizeof(double));
	m_iCountVar = 0;


	m_dXXInv = new double[iSubjectNumber][DIM_TIMEDEP][Dim_MixedModel * Dim_MixedModel];
	memset(m_dXXInv, 0, iSubjectNumber* DIM_TIMEDEP* Dim_MixedModel* Dim_MixedModel * sizeof(double));
	memset(iIncludeSubject, 0, iRiskSet * 2 * sizeof(int));


	memset(dTotalAlpha, 0, iRiskSet*2* DIM_TIMEDEP * Dim_MixedModel * sizeof(double));
	memset(dTotalAlpha2, 0, iRiskSet*2* DIM_TIMEDEP * Dim_MixedModel* Dim_MixedModel * sizeof(double));
	memset(dTotalFFInv, 0, iRiskSet* DIM_TIMEDEP* Dim_MixedModel* Dim_MixedModel * sizeof(double));
}


//////////////////////////////////////////////////////////////////////
// Construction/Destruction

void DeCCox()
{
    //delete m_pcRanNum;

	delete []m_dTij;
	delete []m_pdV;
	delete []m_pdT;
	delete []m_pdC;
	delete []m_piDelta;
	delete []m_pdZ;
	delete []m_pdSortedDeathTime;
	delete []m_piNumberOfDeathBeforeEvent;
	delete []m_pdObservedCovariate;
	delete []m_pdObservedTime;
	delete []m_pdTheta;
	delete []m_piIncludedDeathTime;
	delete []m_pdE0;
	delete []m_pdE0_Tau;
	delete []m_pdE1;
	delete []m_pdE1_Tau;
	
	if(m_pdSSResidual!=NULL)
	    delete []m_pdSSResidual;
	if(m_piCountOfObs!=NULL)
	    delete []m_piCountOfObs;
   
	delete []m_pcAlpha;
	delete []m_pdAlpha_Var;
	delete []m_pdG;
	delete []m_piNumberOfDeathAtDeathTime;
	delete []m_piMaxCountOfObs;
	delete []m_piSubjectFailedAtDeathTime;

	if(m_D != NULL)
		delete []m_D;

	delete []m_pdTotalCumHazard;
	delete []m_pdAllDeathTimes;

	delete []m_dXXInv;

}


//////////////////////////////////////////////////////////////////////
// Read data from external files
void Initiate(FILE* fSurvival,FILE* fLongitudinal)
{
	// get V=min(T,C) and delta=I(T<=C);
	GetVAndDeltaFromFile(fSurvival);
	GetObservedCovariateBeforeEventFromFile(fLongitudinal);
    
	SortDataAccordingToV();

	double dTemp[iCov];
	memset(dTemp,0,iCov*sizeof(double));
	SetVarianceOfE(dTemp);

	double dStart[]={-1,0,0};

	SetStartParametersForInteration(dStart);

	GetMedianT();
	GetMedianT_Risk();
}


void SetCoefficentOfProportionalHazardModel(double *dGamma)
{
	memcpy(m_dTrueGamma, dGamma, iCov * sizeof(double));
}

void SetStartParametersForInteration(double *dGamma)
{
	memcpy(m_dStartGamma, dGamma, iCov * sizeof(double));
}

void SetObservationTime(double* dTij)
{
	memcpy(m_dTij,dTij,iObservations*sizeof(double));
}



void SetVarianceOfE(double* dSigmaSq)
{
	for(int i=0; i<iTrueTimeDepCov*(1+iTrueTimeDepCov)/2; i++)
	{
		m_dSigmaSq[i]=dSigmaSq[i];
		m_dSigmaSqHat[i]=m_dSigmaSq[i];
	}
}

void SortDataAccordingToV()
{
	for(int i=0; i<m_iSubjectNumber; i++)
    {
		for(int j=i+1;j<m_iSubjectNumber;j++)
		{
			if(m_pdV[i]>m_pdV[j])
			{
				Exchange(&m_pdV[i],&m_pdV[j]);
				//Exchange(&m_id[i],&m_id[j]);
				Exchange(&m_piDelta[i],&m_piDelta[j]);
				for(int k=0; k<iTrueTimeDepCov;k++)
					Exchange(&m_piCountOfObs[i][k],&m_piCountOfObs[j][k]);
				for(int k=0; k<iTrueTimeDepCov;k++)
				{
					for (int s = 0; s < Dim_MixedModel; s++)
					{
						Exchange(&m_pcAlpha[i][k].a[s], &m_pcAlpha[j][k].a[s]);
					}
				}
				for(int k=0; k<iTrueTimeIndCov;k++)
					Exchange(&m_pdZ[i][k],&m_pdZ[j][k]);
				
			
				for(int m=0; m<iObservations; m++)
				{
					Exchange(&m_pdObservedTime[i][m],&m_pdObservedTime[j][m]);
					for(int r=0; r<iTrueTimeDepCov;r++)
						Exchange(&m_pdObservedCovariate[i][r][m],&m_pdObservedCovariate[j][r][m]);
				}

				Exchange(&m_piMaxCountOfObs[i],&m_piMaxCountOfObs[j]);
			}
		}
	}
}


inline void Exchange(double *a,double *b)
{
	double temp = *a;
	*a = *b;
	*b = temp;
}

inline void Exchange(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

void GetSortedDeathTime(EMethod eMethod)
{
	memset(m_pdSortedDeathTime,0,m_iSubjectNumber*sizeof(double));
	memset(m_piNumberOfDeathAtDeathTime,0,m_iSubjectNumber*sizeof(int));

	// Get all Death Times;
    int j=0;
	for(int i=0; i<m_iSubjectNumber ; i++)
	{
		// 2014.05
		bool bDeath = false;
		if (m_piDelta[i] == 1)
		{
			bDeath = true;
			if (eMethod != Ideal &&  m_piCountOfObs[i][0] <= Order_MixedModel)
				bDeath = false;
		}
		if (bDeath)
		{
			bool bNewDeathTime=true;
			if(j>0)
			{
				for(int s=0; s<j && bNewDeathTime;s++)
				{
					if(m_pdV[i]==m_pdSortedDeathTime[s])
					{
						m_piNumberOfDeathAtDeathTime[s]++;
						bNewDeathTime=false;
					}
				}
			}

			if(bNewDeathTime)
			{
		       m_pdSortedDeathTime[j]=m_pdV[i];
			   m_piNumberOfDeathAtDeathTime[j]=1;
			   m_piSubjectFailedAtDeathTime[j]=i;
		
			   j++;
			}
			else if(j>0)
				m_piNumberOfDeathAtDeathTime[j-1]++;
		}
	}
	
	m_iNumberOfDeathTime=j;

    // Sort the Death Times
	//Sort(m_pdSortedDeathTime,m_iNumberOfDeathTime);
	MultiSort(m_pdSortedDeathTime,m_piNumberOfDeathAtDeathTime,m_iNumberOfDeathTime);
}


void GetNumberOfDeathBeforeEvent()
{
	
	for(int i=0;i<m_iSubjectNumber; i++)
	{
		int j=0;
		while(j<m_iNumberOfDeathTime && m_pdV[i]>=m_pdSortedDeathTime[j] && m_pdSortedDeathTime[j]-m_pdObservedTime[i][m_piCountOfObs[i][0]-1]<=CutOffTime)
		{
			j++;
		}
	
		 m_piNumberOfDeathBeforeEvent[i]=j;
	}

}

////////////////////////////////////////////////////////////////////////
// Get G=(K_n(X-x0),Z) for all subjects 

void GetG(EMethod eMethod, double h, bool bSmooth)
{
	GetSortedDeathTime(eMethod);
	for (int i = 0; i<iSubjectNumber; i++)
	{
		GetGi(eMethod, i, h, bSmooth);
	}
}

//////////////////////////////////////////////////////////////////////
// Get estimate of variance of alpha

void GetVarAlpha()
{
	double temp[Dim_MixedModel * Dim_MixedModel];
	memset(temp, 0, Dim_MixedModel * Dim_MixedModel * sizeof(double));
		
	double tempVar[Dim_MixedModel * Dim_MixedModel];
	memset(tempVar, 0, Dim_MixedModel * Dim_MixedModel * sizeof(double));
	
	for (int s = 0; s < iRiskSet; s++)
	{
		for (int k = 0; k < iTrueTimeDepCov; k++)
		{
			int iIncSubject = 0;
			for (int r = 0; r < iTrueTimeIndCov + 1; r++)
			{
				MultiplyScalar(m_Alpha_E_Hat[s][r][k], dTotalAlpha[s][r][k], 1. / iIncludeSubject[s][r], Dim_MixedModel, 1);
				Multiply(temp, m_Alpha_E_Hat[s][r][k], dTotalAlpha[s][r][k], Dim_MixedModel, 1, Dim_MixedModel);
				SubtractMatrix(m_Alpha_Var_Hat[s][k], dTotalAlpha2[s][r][k], temp, Dim_MixedModel, Dim_MixedModel);
				SumMatrix(tempVar, tempVar, m_Alpha_Var_Hat[s][k], Dim_MixedModel, Dim_MixedModel);
				iIncSubject += iIncludeSubject[s][r];
			}

			MultiplyScalar(temp, dTotalFFInv[s][k], m_dSigmaSqHat[k], Dim_MixedModel, Dim_MixedModel);
			SubtractMatrix(m_Alpha_Var_Hat[s][k], tempVar, temp, Dim_MixedModel, Dim_MixedModel);
			MultiplyScalar(m_Alpha_Var_Hat[s][k], m_Alpha_Var_Hat[s][k], 1. / iIncSubject, Dim_MixedModel, Dim_MixedModel);

			// Ensure positive definite matrix
			double epsilon = 0.001;
			MultiplyScalar(temp, temp, epsilon * 1. / iIncSubject, Dim_MixedModel, Dim_MixedModel);
			if (Dim_MixedModel > 1)
			{
#ifndef QUADRATIC_X
				while (m_Alpha_Var_Hat[s][k][0] < 0 || m_Alpha_Var_Hat[s][k][0] * m_Alpha_Var_Hat[s][k][3] - m_Alpha_Var_Hat[s][k][1] * m_Alpha_Var_Hat[s][k][1] < 0)
				{
					SumMatrix(m_Alpha_Var_Hat[s][k], m_Alpha_Var_Hat[s][k], temp, Dim_MixedModel, Dim_MixedModel);
				}
#else
				while(m_Alpha_Var_Hat[s][k][0] < 0 
					|| m_Alpha_Var_Hat[s][k][0] * m_Alpha_Var_Hat[s][k][4] - m_Alpha_Var_Hat[s][k][1] * m_Alpha_Var_Hat[s][k][1] < 0
					|| m_Alpha_Var_Hat[s][k][0]* m_Alpha_Var_Hat[s][k][4]* m_Alpha_Var_Hat[s][k][8]
						+ m_Alpha_Var_Hat[s][k][1]* m_Alpha_Var_Hat[s][k][5]* m_Alpha_Var_Hat[s][k][6]
						+ m_Alpha_Var_Hat[s][k][3]* m_Alpha_Var_Hat[s][k][7]* m_Alpha_Var_Hat[s][k][2]
						- m_Alpha_Var_Hat[s][k][2]* m_Alpha_Var_Hat[s][k][4]* m_Alpha_Var_Hat[s][k][6]
						- m_Alpha_Var_Hat[s][k][3]* m_Alpha_Var_Hat[s][k][1]* m_Alpha_Var_Hat[s][k][8]
						- m_Alpha_Var_Hat[s][k][0]* m_Alpha_Var_Hat[s][k][7]* m_Alpha_Var_Hat[s][k][5]<0)
				{
					SumMatrix(m_Alpha_Var_Hat[s][k], m_Alpha_Var_Hat[s][k], temp, Dim_MixedModel, Dim_MixedModel);
				}

#endif
			}
		}
	}
}


////////////////////////////////////////////////////////////////////////
// Get G=(K_n(X-x0),Z) for the ith subjects at time t

void 	GetGi(EMethod eMethod, int i,  double h, bool bSmooth)
{
	GetNumberOfDeathBeforeEvent();
	memset(m_pdG[i], 0, iDeathTime*iCov*sizeof(double));
	memset(m_pdTheta[i], 0, iDeathTime * DIM_TIMEDEP * DIM_TIMEDEP * sizeof(double));
	m_piIncludedDeathTime[i]=0;
	switch(eMethod)
	{
		case Ideal:
			GetIdealGi(i);
			break;
		case Naive:
			GetNaiveGi(i);
			break;
		case RC:
		case RRC:
			GetRegCalGi_Linear(i,eMethod);	
			break;
		case SCS:
			if (iTrueTimeDepCov == 1)
				GetCorrScoreGi_Linear_Aug(i, h, eMethod, bSmooth);
			break;
		default:
			GetNaiveGi(i);
			break;
	}
}

void GetIdealGi(int i) 
{
	for(int j=0; j<m_piNumberOfDeathBeforeEvent[i]; j++)
	{
		if(m_pdV[i]>=m_pdSortedDeathTime[j])
		{
			for( int k=0; k<iTimeDepCov; k++)
			{

				int s = Order_MixedModel;
				m_pdG[i][j][k] = 0;
				while (s >= 0)
				{
					m_pdG[i][j][k] = m_pcAlpha[i][0].a[s] + m_pdG[i][j][k] * m_pdSortedDeathTime[j];
						
					s--;
				}
				if (m_pdG[i][j][k] > CutOff_X[k])
					m_pdG[i][j][k] = 1;
				else
					m_pdG[i][j][k] = 0;
			}
			for(int k=0; k<iTimeIndCov;	k++)
			{
				m_pdG[i][j][iTimeDepCov+k] = m_pdZ[i][k];
			}

		}
	}
}

void GetNaiveGi(int i)
{
	CMyPoint cAlphaHat[iTrueTimeDepCov];

	bool bInclude=IsIncludeSubject_Naive(i);
	if(!bInclude)
	{
		m_piIncludedDeathTime[i]=m_iNumberOfDeathTime;
		if(iTrueTimeDepCov==1)
			return;
	}

	countinclude++;

	int iCovStart=0;
	double varAlpha[(2*Dim_MixedModel)*(2*Dim_MixedModel)];
	double pdV[PARM_SIGMA];
	bool bMissingValue=false;
	int numObservedSimul=0;
	
	memset(pdV,0,PARM_SIGMA*sizeof(double));
	bool bSuccess=false;
	if(iTimeDepCov>0)
	{
		int m=0;
		if(iTrueTimeDepCov==1)
		{
			
			if(m_piCountOfObs[i][0]>=Dim_MixedModel)
			{
				bSuccess=LinearRegression(
						&cAlphaHat[0],
						&pdV[0],
						varAlpha,
						m_pdObservedCovariate[i][0],
						m_pdObservedTime[i],
						m_piCountOfObs[i][0],
						m,
						m_dXXInv[i][0],
						false
						);
				m_dfCov[0] += m-Dim_MixedModel;
				m_pdSSResidual[i][0]=pdV[0];

				int k = 0;
				double temp[Dim_MixedModel * Dim_MixedModel];
				int trt = 0;
				if (m_pdZ[i][0] > 0) 
					trt = 1;
				memset(temp, 0, Dim_MixedModel * Dim_MixedModel * sizeof(double));
				for (int s = 0; s < iRiskSet; s++)
				{
					if (m_pdV[i] > m_qtRisk[s])
					{
						SumMatrix(dTotalAlpha[s][trt][k], dTotalAlpha[s][trt][k], cAlphaHat[0].a, Dim_MixedModel, 1);
						Multiply(temp, cAlphaHat[0].a, cAlphaHat[0].a, Dim_MixedModel, 1, Dim_MixedModel);
						SumMatrix(dTotalAlpha2[s][trt][k], dTotalAlpha2[s][trt][k], temp, Dim_MixedModel, Dim_MixedModel);
						SumMatrix(dTotalFFInv[s][k], dTotalFFInv[s][k], m_dXXInv[i][0], Dim_MixedModel, Dim_MixedModel);
						iIncludeSubject[s][trt]++;
					}
				}
			}
		}

		
		if(bInclude)
		{
			bool bFinish = false;  
			for (int j = 0; j < m_piNumberOfDeathBeforeEvent[i] && !bFinish; j++)
			{
				if (m_pdV[i] >= m_pdSortedDeathTime[j])
				{
					for (int k = 0; k < iTimeDepCov; k++)
					{
						
						int s = Order_MixedModel;
						m_pdG[i][j][k] = 0;
						while (s >= 0)
						{
							m_pdG[i][j][k] = cAlphaHat[0].a[s] + m_pdG[i][j][k] * m_pdSortedDeathTime[j];

							s--;
						}
						if (m_pdG[i][j][k] > CutOff_X[k])
							m_pdG[i][j][k] = 1;
						else
							m_pdG[i][j][k] = 0;
						
					}

					for (int k = 0; k < iTimeIndCov; k++)
					{
						m_pdG[i][j][iTimeDepCov + k] = m_pdZ[i][k];
					}
				}
				else
				{
					bFinish = false;  
				}
			}
		}
		
		SumMatrix(m_dSigmaSq,m_dSigmaSq,pdV,PARM_SIGMA,1); 
	}
}


void GetRegCalGi_Linear(int i, EMethod eMethod)
{
	// Get the deathtime that the ith subject would be included in calculation;
	m_piIncludedDeathTime[i] = m_iNumberOfDeathTime; //do not include this subject in calculation;
	bool bInclude = false;

	if (iTimeDepCov == 0 || m_piCountOfObs[i][0] > Order_MixedModel)
	{
		bInclude = true;
		m_piIncludedDeathTime[i] = 0;
	}

	int iCovStartIndex = 0;

	if (iTimeDepCov > 0)
	{
		//m_pdSSResidual[i][k]=0;
		double varAlpha[(2 * Dim_MixedModel) * (2 * Dim_MixedModel)];

		// Get OLS estimate of alpha;
		int index = 0;
		int newindex = 0;
		bool bSuccess = false;
		CMyPoint cAlphaHat[iTrueTimeDepCov];

		double dSSResidual = 0;
		double d2VarX = 0;

		for (int s = 0; s < Dim_MixedModel; s++)
		{
			m_pcAlpha[i][0].a[s] = 0;
		}

		if (m_piIncludedDeathTime[i] < m_iNumberOfDeathTime)
		{

			bool bFinish = false;
			bool bMissingValue = false;
			int numObservedSimul = 0;
			double XX[Dim_MixedModel * Dim_MixedModel];
			memset(XX, 0, Dim_MixedModel * Dim_MixedModel * sizeof(double));


			int m = 0;
			bSuccess = LinearRegression(
				&cAlphaHat[0],
				&dSSResidual,
				m_pdAlpha_Var[i][0],
				m_pdObservedCovariate[i][0],
				m_pdObservedTime[i],
				m_piCountOfObs[i][0],
				m,
				XX,
				true
			);

			for (int s = 0; s < Dim_MixedModel; s++)
			{
				m_pcAlpha[i][0].a[s] = cAlphaHat[0].a[s];
			}

			int iCurrentRiskSet = 0;
			for (int j = m_piIncludedDeathTime[i]; j < m_piNumberOfDeathBeforeEvent[i] && !bFinish; j++)
			{
				if (m_pdV[i] >= m_pdSortedDeathTime[j])
				{
					// compute Xhat
					double Xt[DIM_TIMEDEP * Dim_MixedModel];
					double temp[DIM_TIMEDEP * Dim_MixedModel];
					memset(Xt, 0, DIM_TIMEDEP * Dim_MixedModel * sizeof(double));
					Xt[0] = 1;
					for (int k = 1; k < Dim_MixedModel; k++)
						Xt[k] = Xt[k - 1] * m_pdSortedDeathTime[j];

					for (int k = 0; k < iTimeDepCov; k++)
					{
						int s = Order_MixedModel;
						m_pdG[i][j][k] = 0;
						while (s >= 0)
						{
							m_pdG[i][j][k] = cAlphaHat[0].a[s] + m_pdG[i][j][k] * m_pdSortedDeathTime[j];

							s--;
						}
						
						if (eMethod != RRC)
						{
							Multiply(temp, Xt, m_Alpha_Var_Hat[0][0], 1, Dim_MixedModel, Dim_MixedModel);
							Multiply(&d2VarX, temp, Xt, 1, Dim_MixedModel, 1);
						}
						else
						{
							while (m_pdSortedDeathTime[j] > m_qtRisk[iCurrentRiskSet+1] && iCurrentRiskSet<iRiskSet-1)
							{
								iCurrentRiskSet++;
							}

							Multiply(temp, Xt, m_Alpha_Var_Hat[iCurrentRiskSet][0], 1, Dim_MixedModel, Dim_MixedModel);
							Multiply(&d2VarX, temp, Xt, 1, Dim_MixedModel, 1);
						}

						double dTheta = 0;

						
						Multiply(temp, Xt, m_pdAlpha_Var[i][0], iTimeDepCov, Dim_MixedModel, Dim_MixedModel);
						MultiplyT(&m_pdTheta[i][j][0], temp, Xt, iTimeDepCov, Dim_MixedModel, iTimeDepCov);
						
	
						double scale = 1.;
						if (eMethod == RC || eMethod == RRC)
							scale = 0.8;
						if (m_pdG[i][j][k] > CutOff_X[k])
							m_pdG[i][j][k] = scale * sqrt(d2VarX / (d2VarX + m_pdTheta[i][j][0]));
						else
							m_pdG[i][j][k] = 0;
						
					}
					for (int k = 0; k < iTimeIndCov; k++)
					{
						m_pdG[i][j][iTimeDepCov + k] = m_pdZ[i][k];
					}					
				}
				else
					bFinish = true;
			}
		}
	}
}


void GetCorrScoreGi_Linear_Aug(int i,  double h, EMethod eMethod, bool bSmooth)
{
	// Get the deathtime that the ith subject would be included in calculation;
	m_piIncludedDeathTime[i] = m_iNumberOfDeathTime; //do not include this subject in calculation;
	bool bInclude = false;
		
	if (iTimeDepCov == 0 || m_piCountOfObs[i][0] > Order_MixedModel)
	{
		bInclude = true;
		m_piIncludedDeathTime[i] = 0;
	}
	
	int iCovStartIndex = 0;

	if (iTimeDepCov>0)
	{
		double varAlpha[(2 * Dim_MixedModel)*(2 * Dim_MixedModel)];

		// Get OLS estimate of alpha;
		int index = 0;
		int newindex = 0;
		bool bSuccess = false;
		CMyPoint cAlphaHat[iTrueTimeDepCov];

		double dSSResidual = 0;
		double d2VarX = 0;

		for (int s = 0; s < Dim_MixedModel; s++)
		{
			m_pcAlpha[i][0].a[s] = 0;
		}

		if (m_piIncludedDeathTime[i]<m_iNumberOfDeathTime)
		{
			
			bool bFinish = false;
			bool bMissingValue = false;
			int numObservedSimul = 0;
			double XX[Dim_MixedModel * Dim_MixedModel];
			memset(XX, 0, Dim_MixedModel * Dim_MixedModel * sizeof(double));

			
			int m = 0;
			bSuccess = LinearRegression(
				&cAlphaHat[0],
				&dSSResidual,
				//varAlpha,
				m_pdAlpha_Var[i][0],
				m_pdObservedCovariate[i][0],
				m_pdObservedTime[i],
				m_piCountOfObs[i][0],
				m,
				XX,
				true
				);

			for (int s = 0; s < Dim_MixedModel; s++)
			{
				m_pcAlpha[i][0].a[s] = cAlphaHat[0].a[s];
			}
			
			int iCurrentRiskSet = 0;
			for (int j = m_piIncludedDeathTime[i]; j<m_piNumberOfDeathBeforeEvent[i] && !bFinish; j++)
			{
				if (m_pdV[i] >= m_pdSortedDeathTime[j])
				{
					// compute Xhat

					double Xt[DIM_TIMEDEP*Dim_MixedModel];
					double temp[DIM_TIMEDEP*Dim_MixedModel];
					memset(Xt, 0, DIM_TIMEDEP*Dim_MixedModel*sizeof(double));
					Xt[0] = 1;					
					for (int k = 1; k < Dim_MixedModel; k++)
						Xt[k] = Xt[k - 1] * m_pdSortedDeathTime[j];


					for (int k = 0; k < iTimeDepCov; k++)
					{
						int s = Order_MixedModel;
						m_pdG[i][j][k] = 0;
						while (s >= 0)
						{
							m_pdG[i][j][k] = cAlphaHat[0].a[s] + m_pdG[i][j][k] * m_pdSortedDeathTime[j];

							s--;
						}

							
							if (bSmooth)
							{
								double x = (m_pdG[i][j][k] - CutOff_X[k]) / h;

								m_pdG[i][j][k] = 1 / (1 + exp(-(m_pdG[i][j][k] - CutOff_X[k]) / h));
								m_pdG_der[i][j][k] = m_pdG[i][j][k] * (1 - m_pdG[i][j][k]) / h;
							}
						else 
						{
							Multiply(temp, Xt, m_Alpha_Var_Hat[0][k], 1, 2, 2);
							Multiply(&d2VarX, temp, Xt, 1, 2, 1);
							d2VarX = 2 * sqrt(d2VarX);
							m_pdG[i][j][k] /= d2VarX;
						}
					}
					for(int k = 0; k<iTimeIndCov; k++)
					{
						m_pdG[i][j][iTimeDepCov + k] = m_pdZ[i][k];
					}

					
					Multiply(temp, Xt, m_pdAlpha_Var[i][0], 1, 2, 2);					
					Multiply(temp, temp, Xt, 1, 2, 1);
					
					m_maxVar[0] += temp[0];
					m_iCountVar++;
					for (int k = 0; k < iTimeDepCov; k++)
					{
						Xt[k*Dim_MixedModel] = m_pdG_der[i][j][k];
						for (int s = 1; s < Dim_MixedModel; s++)
						{
							Xt[k*Dim_MixedModel+s] = Xt[k * Dim_MixedModel+s - 1] * m_pdSortedDeathTime[j];
						}
					}
					
					Multiply(temp, Xt, m_pdAlpha_Var[i][0], iTimeDepCov, Dim_MixedModel, Dim_MixedModel);					
					MultiplyT(m_pdTheta[i][j], temp, Xt, iTimeDepCov, Dim_MixedModel, iTimeDepCov);

				}
				else
					bFinish = true;
			}
		}
	}
}

int GetIndexOfIncludedDeathTime(int i,int j,int iOldIndex,int iCovInd)
{
	int iIndex=iOldIndex;
	bool bFound=false;
	int iStopIndex=m_piCountOfObs[i][iCovInd];
	int iStartIndex=0;

	for(int k=0; k<iCovInd; k++)
	{
		iStartIndex+=m_piCountOfObs[i][k];
	}
	iStopIndex+=iStartIndex;

	
	for(int k=iStartIndex+iOldIndex; k<iStopIndex && !bFound; k++)
	{
		if (m_pdObservedTime[i][k] <= m_pdSortedDeathTime[j])
			iIndex++;
		else
			bFound=true;
	}

	return(iIndex);
}



double GetSigmaHat()
{
	if(iTimeDepCov>0)
	{
		for(int k=0; k<PARM_SIGMA; k++)
		{
			m_dSigmaSqHat[k]=m_dSigmaSq[k]/m_dfCov[k];
		}
		
	}

	GetVarAlpha();
	double h = sqrt(m_dSigmaSqHat[0] / m_iNumberOfDeathTime);
	return(h);
}

bool LinearRegression(CMyPoint* pcAlphaHat,double* pdSSResidual, double* varAlpha, double* pdY,double* pdX, int iCountOfObs, int & n, double*XX, bool bComputeVarAlpha)
{
	bool bSuccess=true;

	//double XX[Dim_MixedModel*Dim_MixedModel];      // X^T*X
	double XY[Dim_MixedModel];          // X^T*Y
	double YY=0;             // Y^T*Y
	double YXb=0;        // Y^T*X*alpha

	memset(XX,0,Dim_MixedModel*Dim_MixedModel*sizeof(double));
	memset(XY,0,Dim_MixedModel*sizeof(double));


	n=0;
	for(int j=0;j<iCountOfObs;j++)
	{
		if(pdY[j]>=-1e20)
		{
			double temp=1;;
			int index=0;
			for(int s=0; s<2*Dim_MixedModel-1; s++)
			{
				XX[index]+=temp;
									
				if(s<Dim_MixedModel)
				{
					XY[s]+=pdY[j]*temp;
				}

				if(s<Dim_MixedModel-1)
					index++;
				else
					index+=Dim_MixedModel;

				temp*=pdX[j];
			}
			n++;
		}
	}

	for(int i=1;i<Dim_MixedModel; i++)
	{
		for(int j=0; j<Dim_MixedModel-i;j++)
		{
			XX[i*Dim_MixedModel+j]=XX[i+j];
		}
		for(int j=Dim_MixedModel-i;j<Dim_MixedModel-1;j++)
		{
			XX[i*Dim_MixedModel+j]=XX[((i+j)%(Dim_MixedModel-1)+1)*Dim_MixedModel-1];
		}
	}

	Inverse(XX,XX,Dim_MixedModel);

	Multiply(pcAlphaHat->a,XX,XY,Dim_MixedModel,Dim_MixedModel,1);

	for(int j=0;j<iCountOfObs;j++)
	{
		//if(pdY[j]>=0)
		if(pdY[j]>=-1e20)
		{
			double Xb=0;
			double temp=1;
			for(int i=0; i<Dim_MixedModel; i++)
			{
				Xb+=temp*pcAlphaHat->a[i];
				temp*=pdX[j];
			}
			YXb+=pdY[j]*Xb;
			YY+=pdY[j]*pdY[j];
		}
		
	}

	*pdSSResidual=YY-YXb;

	if(bComputeVarAlpha)
	{
		memcpy(varAlpha,XX,Dim_MixedModel*Dim_MixedModel*sizeof(double));
		for(int i=0;i<Dim_MixedModel;i++)
		{
			for(int j=0;j<Dim_MixedModel;j++)
				varAlpha[i*Dim_MixedModel+j] *= m_dSigmaSqHat[0];
		}
		
	}
    return bSuccess;
}


bool ProportionalHazardRegression(double* pdGamma, double* pdSeGamma, EMethod eMethod, bool bComputeSE, double h)
{
	bool bSuccess=true;
	bool bSolutionFound=false;
	int iIteration=0;
	double dGamma0[iParm],dGamma1[iParm];
    double dPhi[iCov];
	for(int k=0; k<iCov; k++)
	{
		dGamma0[k]=m_dStartGamma[k];
		dGamma1[k]=m_dStartGamma[k];
		dPhi[k]=0;
	}
	double dInformation[iCov*iCov],dInverseInformation[iCov*iCov];
	memset(dInformation,0,iCov*iCov*sizeof(double));
	memset(dInverseInformation,0,iCov*iCov*sizeof(double));
    
	
		while( bSuccess && !bSolutionFound && iIteration<MAX_ITERATION)
		{
			bSuccess=GetPhi(dGamma0,dPhi,eMethod);
			if(bSuccess)
			{
				bSuccess=GetInformation(dInformation,dGamma0,eMethod);
				if(bSuccess)
					bSuccess=GetInversedInformation(dInverseInformation,dInformation);
				
				if (bSuccess)
				{
					GetNewGamma(dGamma1,dGamma0,dPhi,dInverseInformation);
					bSolutionFound=IsSolutionFound(dGamma1,dGamma0, TOLERANCE);
					memcpy(dGamma0,dGamma1,iCov*sizeof(double));
				}	
				iIteration++; 
			}
		}
		if(bSuccess && bSolutionFound && !isnan(dGamma0[0]))
		{
			memcpy(pdGamma,dGamma1,iCov*sizeof(double));
			
			if (bComputeSE)
			{
				bSolutionFound = GetSE(pdSeGamma, pdGamma, eMethod);
			}

			
		}
		
	return(bSolutionFound);
	
}


void GetNewGamma(double* dGamma1,double* dGamma0,double* dPhi,double* dInverseInformation)
{
	Multiply(dGamma1,dInverseInformation,dPhi,iCov,iCov,1);
	for(int k=0; k<iCov; k++)
		dGamma1[k]=dGamma0[k]+dGamma1[k];
}


bool  GetInformation(double* pdInformation, double* pdGamma, EMethod eMethod)
{
    //Calculate the information matrix;
	memset(pdInformation,0,iCov*iCov*sizeof(double));
	
	for(int i=0;i<m_iSubjectNumber;i++)
	{
		int k=m_piNumberOfDeathBeforeEvent[i]-1;

		if(IsDead(i,k))
		{
			double dE0sq=m_pdE0[k]*m_pdE0[k];
			if(fabs(m_pdE0[k])<MIN_DOUBLE)
		        return(false);

			double dNumerator[2][DIM_TIMEDEP];
			double dDenominator = 0;
			memset(dNumerator, 0, 2 * DIM_TIMEDEP*sizeof(double));

	
			for(int m=0; m<iCov; m++)
			{
				for(int n=0; n<iCov; n++)
				{
					int r=m*iCov+n;
					double kernel = 1;
					double dHijk_Taum = GetHijk_Taum(i, k, m, n, pdGamma, eMethod);
					pdInformation[r] -= kernel*(dHijk_Taum
						-(m_pdE1_Tau[k][m][n]*m_pdE0[k]-m_pdE1[k][m]*m_pdE0_Tau[k][n])/dE0sq);
				}
			}
		}
	}

    
	return(true);
}

bool GetInversedInformation(double* pdInverseInformation,double* pdInformation)
{
	bool bSuccess=Inverse(pdInverseInformation,pdInformation,iCov);
    return bSuccess;
}

bool GetPhi(double* pdGamma,double* pdPhi,EMethod eMethod)
{
	bool bSuccess=true;

	double test = 0;

	for(int m=0; m<iCov; m++)
		pdPhi[m]=0;
	
	bSuccess=GetIntermediateData(false,pdGamma,eMethod,false);
	for(int i=0;i<m_iSubjectNumber && bSuccess; i++)
	{
		int k=m_piNumberOfDeathBeforeEvent[i]-1;
		if (IsDead(i,k))
		{
			double dNumerator[DIM_TIMEDEP];
			double dDenominator = 0;
			memset(dNumerator, 0, DIM_TIMEDEP*sizeof(double));
			for(int m=0; m<iCov; m++)
			{
				double Hijk=GetHijk(i,k,m,pdGamma,eMethod);
				
				double kernel = 1; 
			    pdPhi[m]+=kernel*(Hijk-m_pdE1[k][m]/m_pdE0[k]);
			}
		}

	}

	
	return(bSuccess);
}


double GetHijk(int i, int j, int k, double* dGamma, EMethod eMethod)
{
	double dHijk=0;
	if(IsAtRisk(i,j))
		dHijk=m_pdG[i][j][k];

	return(dHijk);
}

// i: Subject Index;
// j: Death Time Index;
// k: kth Covariate;
// m: take derivative wrt the mth parameter;
double GetHijk_Taum(int i, int j, int k, int m, double* dGamma, EMethod eMethod)
{
	double dHijk_Taum=0;
	return(dHijk_Taum);
}


bool GetExpXbeta(int i, int j, double& dE0ij, double* dGamma, EMethod eMethod)
{
	double tempE0ij = 0;
	dE0ij = 0;
	if (IsAtRisk(i, j))
	{
		// Get E0ij 
		double temp = 0;
		for (int k = 0; k < iTimeDepCov; k++)
		{
			temp += dGamma[k] * GetHijk(i, j, k, dGamma, eMethod);
		}
		for (int k = iTimeDepCov; k < iCov; k++)
			temp += dGamma[k] * m_pdG[i][j][k];
		if (temp < log(MAX_DOUBLE))
		{
			dE0ij = exp(temp);
		}
		else
		{
			return(false);
		}
	}
		
	return(true);
}

// i: subject
// j: death time
bool GetE0iAndE1i(int i, int j, double& dE0ij, double* dE1ij, double* dGamma, EMethod eMethod)
{
	double tempE0ij=0;
	dE0ij=0;
	for(int k=0; k<iCov;k++)
		dE1ij[k]=0;
	if(IsAtRisk(i,j))
	{
		// Get E0ij 
		double temp=0;
		for(int k=0; k<iTimeDepCov; k++)
		{
			temp+=dGamma[k]*GetHijk(i,j,k,dGamma,eMethod);
		}
		double temp1[iCov];
		memset(temp1, 0, iCov*sizeof(double));
		if (eMethod == SCS)
		{			
			// modify to avoid overflow;
			Multiply(temp1,dGamma,m_pdTheta[i][j],1,iTimeDepCov,iTimeDepCov);
			// modify to avoid overflow;
			double temp2=0;
			Multiply(&temp2,temp1,dGamma,1,iTimeDepCov,1);
			temp -= temp2/2;
		}

		for(int k=iTimeDepCov;k<iCov;k++)
			temp+=dGamma[k]*m_pdG[i][j][k];
		double tempE0ij_laplace = 0;
		if(temp<log(MAX_DOUBLE))
		{
			tempE0ij=exp(temp);
			tempE0ij_laplace = tempE0ij;
			
			dE0ij += tempE0ij_laplace;
		}
		else
		{
			return(false);
		}
		for(int k=0; k<iCov; k++)
		{
			if (eMethod == SCS  && k<iTimeDepCov)
			{
				dE1ij[k] += (GetHijk(i, j, k, dGamma, eMethod) - temp1[k])*tempE0ij;
			}
			else
			{
				dE1ij[k] += GetHijk(i, j, k, dGamma, eMethod)*tempE0ij;
			}
		}
	}
	return(true);
}

// i: subject;
// j: death time;
// k: the kth parameter;
double GetE0i_Tau(int i,int j, int k, double dE0ij, double* dGamma, EMethod eMethod)
{
	double dE0ij_Tauk=0;

	if(k<iTimeDepCov)
	{
		double temp=GetHijk(i,j,k,dGamma,eMethod);
		for(int m=0;m<iTimeDepCov;m++)
		{
			double dHijm_Tauk=GetHijk_Taum(i,j,m,k,dGamma,eMethod);
			if (eMethod == SCS)
			{
				// modify to avoid overflow;
				temp += dGamma[m]*dHijm_Tauk-dGamma[m]*m_pdTheta[i][j][m*iTimeDepCov+k];
				// modify to avoid overflow;
			}
		}
		dE0ij_Tauk = dE0ij * temp;
	}
	else if (k < iCov)
	{
		dE0ij_Tauk = dE0ij * m_pdG[i][j][k];
	}
	else if(iTrueTimeDepCov==1)
	{
		double temp=0;
		for(int m=0;m<iTimeDepCov;m++)
		{
			temp +=dGamma[m]*GetHijk_Taum(i,j,m,k,dGamma,eMethod);
		}
		if (eMethod == SCS)
		{
			double temp1[DIM_TIMEDEP];
			Multiply(temp1,dGamma,m_pdTheta[i][j],1,iTimeDepCov,iTimeDepCov);
			double temp2=0;
			Multiply(&temp2,temp1,dGamma,1,iTimeDepCov,1);
		
			temp-=temp2/m_dSigmaSqHat[0]/2;
		}
		
		dE0ij_Tauk = dE0ij * temp;
	}

	return(dE0ij_Tauk);
}

// j: death time
bool GetE0AndE1(bool bVariance, int j, double *dGamma,EMethod eMethod, bool bE0_Only)
{
	int k=0, m=0;
	m_pdE0[j]=0;
	double dE0ij=0;
	for(k=0;k<iCov;k++)
		m_pdE1[j][k]=0;

	for(k=0;k< iParmRegCal;k++)
		m_pdE0_Tau[j][k]=0;

	for(k=0;k<iCov;k++)
	{
		for(m=0;m<iParmRegCal;m++)
			m_pdE1_Tau[j][k][m]=0;
	}

	double dHij[iCov];
	double dE0i_Tau[iParmRegCal];
	memset(dHij,0,iCov*sizeof(double));
	memset(dE0i_Tau,0, iParmRegCal *sizeof(double));
	
	bool bSuccess=true;
	
	for(int i=0;i<m_iSubjectNumber;i++)
	{
		if(IsAtRisk(i,j))
		{
			// Get E0ij 
			double dE0ij=0, dE1ij[iCov];
			bSuccess=GetE0iAndE1i(i,j,dE0ij,dE1ij,dGamma,eMethod);
			if(!bSuccess)
				return(false);

			m_pdE0[j]+=dE0ij;
			
			if (!bE0_Only)
			{
				for (k = 0; k < iCov; k++)
				{
					// Get E1ijk;
					dHij[k] = GetHijk(i, j, k, dGamma, eMethod);
					//double dE1ijk=dHij[k]*dE0ij;

					m_pdE1[j][k] += dE1ij[k];

					// Get E0i_Tau;
					if (k < iTimeDepCov)
					{
						dE0i_Tau[k] = GetE0i_Tau(i, j, k, dE0ij, dGamma, eMethod);
						m_pdE0_Tau[j][k] += dE0i_Tau[k];
					}
					else
					{
						dE0i_Tau[k] = dE0ij * m_pdG[i][j][k];
						m_pdE0_Tau[j][k] += dE0i_Tau[k];
					}

				}

				if (bVariance && iTrueTimeDepCov == 1)
				{
					for (k = 0; k < iTrueTimeDepCov; k++)
					{
						// Get E0i_Tau;
						dE0i_Tau[k + iCov] = GetE0i_Tau(i, j, k + iCov, dE0ij, dGamma, eMethod);
						m_pdE0_Tau[j][k + iCov] += dE0i_Tau[k + iCov];
					}
				}

				double temp1[iCov];
				memset(temp1, 0, iCov * sizeof(double));
				if (eMethod == SCS)
				{
					Multiply(temp1, dGamma, m_pdTheta[i][j], 1, iTimeDepCov, iTimeDepCov);
				}

				double dSn = m_pdG[i][j][0];
				double dSn_der = m_pdG_der[i][j][0];
				double dSn_der2 = m_pdG_der2[i][j][0];

				for (k = 0; k < iCov; k++)
				{
					for (int m = 0; m < iCov; m++)
					{
						// Get E1ik_Taum
						double dE1ik_Taum = 0;
							dE1ik_Taum = GetHijk_Taum(i, j, k, m, dGamma, eMethod) * dE0ij + dHij[k] * dE0i_Tau[m];


						if ( eMethod == SCS && k < iTimeDepCov && m < iTimeDepCov)
						{
							dE1ik_Taum = dE1ik_Taum - m_pdTheta[i][j][k * iTimeDepCov + m] * dE0ij - temp1[k] * dE0i_Tau[m];
						}
						m_pdE1_Tau[j][k][m] += dE1ik_Taum;


					}

					if (bVariance && iTrueTimeDepCov == 1)
					{
						for (int m = iCov; m < iParm; m++)
						{
							{
								double dE1ik_Taum = GetHijk_Taum(i, j, k, m, dGamma, eMethod) * dE0ij + dHij[k] * dE0i_Tau[m];
								m_pdE1_Tau[j][k][m] += dE1ik_Taum;
								if (eMethod == SCS && k < iTimeDepCov)
								{
									m_pdE1_Tau[j][k][m] += -temp1[k] / m_dSigmaSqHat[0] * dE0ij - temp1[k] * dE0i_Tau[m];
								}
							}
						}
					}
				}
			}
		}
	}

	return(true);
}



bool GetE0AndE1All(bool bVariance, double *dGamma, EMethod eMethod)
{
	int k = 0, m = 0;
	memset(m_pdE0, 0, iDeathTime*sizeof(double));	
	memset(m_pdE0_Tau, 0, iDeathTime* iParmRegCal *sizeof(double));
	memset(m_pdE1, 0, iDeathTime*iCov*sizeof(double));
	memset(m_pdE1_Tau, 0, iDeathTime*iCov* iParmRegCal *sizeof(double));
	

	double dHij[iCov];
	double dE0i_Tau[iParm];
	memset(dHij, 0, iCov*sizeof(double));
	memset(dE0i_Tau, 0, iParm*sizeof(double));

	bool bSuccess = true;

	int i = m_iSubjectNumber - 1;
	for (int j = m_iNumberOfDeathTime - 1; j >= 0 && bSuccess; j--)
	{
		if (j < m_iNumberOfDeathTime - 1)
		{
			m_pdE0[j] = m_pdE0[j + 1];
			memcpy(m_pdE1[j], m_pdE1[j + 1], iCov*sizeof(double));
			memcpy(m_pdE0_Tau[j], m_pdE0_Tau[j + 1], iParm*sizeof(double));
			memcpy(m_pdE1_Tau[j], m_pdE1_Tau[j + 1], iCov*iParm*sizeof(double));
		}
		while (i >= 0 && IsAtRisk(i, j))
		{
			// Get E0ij 
			double dE0ij = 0, dE1ij[iCov];
			bSuccess = GetE0iAndE1i(i, j, dE0ij, dE1ij, dGamma, eMethod);
			if (!bSuccess)
				return(false);

			m_pdE0[j] += dE0ij;

			for (k = 0; k < iCov; k++)
			{
				// Get E1ijk;
				dHij[k] = GetHijk(i, j, k, dGamma, eMethod);
				//double dE1ijk=dHij[k]*dE0ij;

				m_pdE1[j][k] += dE1ij[k];

				// Get E0i_Tau;
				if (k < iTimeDepCov)
				{
					dE0i_Tau[k] = GetE0i_Tau(i, j, k, dE0ij, dGamma, eMethod);
					m_pdE0_Tau[j][k] += dE0i_Tau[k];
				}
				else
				{
					//dE0i_Tau[k]=dE0ij*m_pdZ[i][k-iTimeDepCov];
					dE0i_Tau[k] = dE0ij*m_pdG[i][j][k];
					m_pdE0_Tau[j][k] += dE0i_Tau[k];
				}

			}

			if (bVariance && iTrueTimeDepCov == 1)
			{
				for (k = 0; k < iTrueTimeDepCov; k++)
				{
					// Get E0i_Tau;
					dE0i_Tau[k + iCov] = GetE0i_Tau(i, j, k + iCov, dE0ij, dGamma, eMethod);
					m_pdE0_Tau[j][k + iCov] += dE0i_Tau[k + iCov];
				}
			}

			double temp1[iCov];
			memset(temp1, 0, iCov*sizeof(double));
			if (eMethod == SCS)
			{
				Multiply(temp1, dGamma, m_pdTheta[i][j], 1, iTimeDepCov, iTimeDepCov);
			}

			for (k = 0; k < iCov; k++)
			{
				for (int m = 0; m < iCov; m++)
				{
					// Get E1ik_Taum
					double dE1ik_Taum = GetHijk_Taum(i, j, k, m, dGamma, eMethod)*dE0ij + dHij[k] * dE0i_Tau[m];
					if (eMethod == SCS && k < iTimeDepCov && m < iTimeDepCov)
					{
						dE1ik_Taum = dE1ik_Taum - m_pdTheta[i][j][k*iTimeDepCov + m] * dE0ij - temp1[k] * dE0i_Tau[m];
					}
					m_pdE1_Tau[j][k][m] += dE1ik_Taum;
				}

				if (bVariance && iTrueTimeDepCov == 1)
				{
					for (int m = iCov; m < iParm; m++)
					{
						double dE1ik_Taum = GetHijk_Taum(i, j, k, m, dGamma, eMethod)*dE0ij + dHij[k] * dE0i_Tau[m];
						m_pdE1_Tau[j][k][m] += dE1ik_Taum;
						if ( eMethod == SCS && k < iTimeDepCov)
						{
							m_pdE1_Tau[j][k][m] += -temp1[k] / m_dSigmaSqHat[k] * dE0ij - temp1[k] * dE0i_Tau[m];

						}
					}
				}
			}

			i--;
		}
	}

	return(true);
}



// i: the ith subject;
// j: the jth time;
bool IsDead(int i,int j)
{
	bool bIsDead=(j>=0 && m_piDelta[i]==1 && j==m_piNumberOfDeathBeforeEvent[i]-1 &&  m_piIncludedDeathTime[i]<=j);
	return(bIsDead);
}


bool IsAtRisk(int i,int j)
{
    //bool bIsAtRisk=(j<m_piNumberOfDeathBeforeEvent[i] && m_piIncludedDeathTime[i]<=j);
	bool bIsAtRisk = (j<m_piNumberOfDeathBeforeEvent[i] && m_piIncludedDeathTime[i] <= j && m_pdSortedDeathTime[j]<=m_pdV[i]);
	return(bIsAtRisk);
}



bool GetSE(double* pdSeGamma, double* pdGamma, EMethod eMethod)
{
	bool bSuccess=true;
	if (eMethod == SCS)
	{
		if(iTrueTimeDepCov==1)
			bSuccess=GetSeForCondScore_Linear(pdSeGamma,pdGamma,eMethod);
	}	
	else
		bSuccess=GetSeForOther(pdSeGamma,pdGamma,eMethod);
	return(bSuccess);
}

bool GetSeForOther(double* pdSeGamma, double* pdGamma, EMethod eMethod)
{
	double dA[iCov*iCov],dB[iCov*iCov],dInvA[iCov*iCov];
	memset(dA,0,iCov*iCov*sizeof(double));
	memset(dB,0,iCov*iCov*sizeof(double));
	memset(dInvA,0,iCov*iCov*sizeof(double));

    int i=0,j=0,k=0,m=0;

	bool bSuccess=GetIntermediateData(true,pdGamma,eMethod,false);

	double dHBar[iCov],dHBar_Tau[iCov][iCov];
	
    for(int i=0; i<m_iSubjectNumber;i++)
	{
		double dPhii[iCov];        
		double dDPhii[iCov][iCov];
		memset(dPhii,0,iCov*sizeof(double));
		memset(dDPhii,0,iCov*iCov*sizeof(double));
	
		if(IsIncludeSubject_Naive(i) || eMethod==Ideal)
		{
			for(int j=0; j<m_iNumberOfDeathTime; j++)
			{
				if(IsAtRisk(i,j))
				{
					double dE0sq=m_pdE0[j]*m_pdE0[j];
					
					for(k=0;k<iCov;k++)
					{
						dHBar[k]=m_pdE1[j][k]/m_pdE0[j];
						for(m=0;m<iCov;m++)
						{
							dHBar_Tau[k][m]=(m_pdE1_Tau[j][k][m]*m_pdE0[j]-m_pdE1[j][k]*m_pdE0_Tau[j][m])/dE0sq;
						}
					}

					int iDeathAtTime=m_piNumberOfDeathAtDeathTime[j];
					
					double dE0ij=0, dE1ij[iCov];
					bool bSuccess=GetE0iAndE1i(i,j,dE0ij,dE1ij,pdGamma,eMethod);
					if(!bSuccess)
						return(false);
					double dCorrectN=-iDeathAtTime*dE0ij/m_pdE0[j];
					if(IsDead(i,j))
						dCorrectN+=1;
					double dCorrectN_Tau[iParm];
					for(m=0;m<iCov;m++)
					{
						double dE0i_Taum=GetE0i_Tau(i,j,m,dE0ij,pdGamma,eMethod);
						dCorrectN_Tau[m]=-iDeathAtTime*(dE0i_Taum*m_pdE0[j]-dE0ij*m_pdE0_Tau[j][m])/dE0sq;
					}

					for(k=0;k<iCov;k++)
					{
						double Hijk=GetHijk(i,j,k,pdGamma,eMethod);
						dPhii[k] += (Hijk - dHBar[k])*dCorrectN;
						for(m=0;m<iCov;m++)
						{
							double dHijk_taum = GetHijk_Taum(i, j, k, m, pdGamma, eMethod);
							dDPhii[k][m] += ((dHijk_taum
								- dHBar_Tau[k][m])*dCorrectN + (Hijk - dHBar[k])*dCorrectN_Tau[m]);
						}
					}

				}
			}
			

			for(k=0;k<iCov;k++)
			{
				for(m=0;m<iCov;m++)
				{
					dA[k*iCov + m] += dDPhii[k][m];
				}
			}

			for(k=0;k<iCov;k++)
			{
				for(m=k;m<iCov;m++)
				{
					dB[k*iCov+m]+=dPhii[k]*dPhii[m];
				}
			}

		}
	}

	for(k=0;k<iCov;k++)
	{
		for(m=0;m<k;m++)
		{
			dB[k*iCov+m]+=dB[m*iCov+k];
		}
	}

	double dV[iCov*iCov];
	double dInvATranspose[iCov*iCov];
	Inverse(dInvA,dA,iCov);
	for(k=0;k<iCov;k++)
	{
		for(m=0;m<iCov;m++)
		{
			dInvATranspose[k*iCov+m]=dInvA[m*iCov+k];
		}
	}

	Multiply(dV,dInvA,dB,iCov,iCov,iCov);
	Multiply(dV,dV,dInvATranspose,iCov,iCov,iCov);
	
	for(k=0;k<iCov;k++)
	{
		if(dV[k*iCov+k]<0)
			return(false);
		pdSeGamma[k]=sqrt(dV[k*iCov+k]);
	}

	return(true);
}


bool GetSeForCondScore_Linear(double* pdSeGamma,double* pdGamma,EMethod eMethod)
{
	double dA[iParm*iParm],dB[iParm*iParm],dInvA[iParm*iParm];
	memset(dA,0,iParm*iParm*sizeof(double));
	memset(dB,0,iParm*iParm*sizeof(double));
	memset(dInvA,0,iParm*iParm*sizeof(double));

    int i=0,j=0,k=0,m=0;

	for(int i=0; i<PARM_SIGMA; i++)
	{
		pdGamma[iCov+i] = m_dSigmaSqHat[i];
	}

	bool bSuccess=GetIntermediateData(true,pdGamma,eMethod,false);

	double dHBar[iCov],dHBar_Tau[iCov][iParm];
	
    for(int i=0; i<m_iSubjectNumber;i++)
	{
		double dPhii[iParm];        
		double dDPhii[iParm][iParm];
		memset(dPhii,0,iParm*sizeof(double));
		memset(dDPhii,0,iParm*iParm*sizeof(double));
		for(k=iCov;k<iParm;k++)
		{
			int s=k-iCov;
			if(m_piCountOfObs[i][s]>Dim_MixedModel)
			{
				int r=k+iParm*k;
				dPhii[k]=m_pdSSResidual[i][s]-(m_piCountOfObs[i][s]-Dim_MixedModel)*m_dSigmaSqHat[s];
				dDPhii[k][k]=-(m_piCountOfObs[i][s]-Dim_MixedModel);
			}
		}
	

		if(IsIncludeSubject_Naive(i))
		{
			for(int j=0; j<m_iNumberOfDeathTime; j++)
			{
				if(IsAtRisk(i,j))
				{
					double dE0sq=m_pdE0[j]*m_pdE0[j];
					
					for(k=0;k<iCov;k++)
					{
						dHBar[k]=m_pdE1[j][k]/m_pdE0[j];
						for(m=0;m<iParm;m++)
						{
							dHBar_Tau[k][m]=(m_pdE1_Tau[j][k][m]*m_pdE0[j]-m_pdE1[j][k]*m_pdE0_Tau[j][m])/dE0sq;
						}
					}

					int iDeathAtTime=m_piNumberOfDeathAtDeathTime[j];
					
					double dE0ij=0, dE1ij[iCov];
					bSuccess=GetE0iAndE1i(i,j,dE0ij,dE1ij,pdGamma,eMethod);
					if(!bSuccess)
						return(false);
					bool bIsDead=IsDead(i,j);

					double dNumerator[4][DIM_TIMEDEP];
					double dDenominator = 0;
					memset(dNumerator, 0, 4 * DIM_TIMEDEP*sizeof(double));

					for(k=0;k<iCov;k++)
					{
						double kernel = 1;
						double dHijk = GetHijk(i, j, k, pdGamma, eMethod);
						if (bIsDead)
						{
							dPhii[k] += kernel*(dHijk - dHBar[k]);
						}
						dPhii[k] -= kernel*iDeathAtTime*(dE1ij[k]*m_pdE0[j]-dE0ij*m_pdE1[j][k])/dE0sq;
						for(m=0;m<iParm;m++)
						{
							if(bIsDead)
							{
								double dHijk_Taum = GetHijk_Taum(i, j, k, m, pdGamma, eMethod);
								
								dDPhii[k][m] += kernel*(dHijk_Taum - dHBar_Tau[k][m]);
							}
						}
					}

				}
			}
			

			for(k=0;k<iParm;k++)
			{
				for(m=0;m<iParm;m++)
				{
					dA[k*iParm+m]+=dDPhii[k][m];
				}
			}

			for(k=0;k<iParm;k++)
			{
				for(m=k;m<iParm;m++)
				{
					dB[k*iParm+m]+=dPhii[k]*dPhii[m];
				}
			}

		}
	}

	for(k=0;k<iParm;k++)
	{
		for(m=0;m<k;m++)
		{
			dB[k*iParm+m]+=dB[m*iParm+k];
		}
	}

	double dV[iParm*iParm];
	double dInvATranspose[iParm*iParm];
	Inverse(dInvA,dA,iParm);
	for(k=0;k<iParm;k++)
	{
		for(m=0;m<iParm;m++)
		{
			dInvATranspose[k*iParm+m]=dInvA[m*iParm+k];
		}
	}

	Multiply(dV,dInvA,dB,iParm,iParm,iParm);
	Multiply(dV,dV,dInvATranspose,iParm,iParm,iParm);
	
	for(k=0;k<iParm;k++)
	{
		if(dV[k*iParm+k]<0)
			return(false);
		pdSeGamma[k]=sqrt(dV[k*iParm+k]);
	}

	return(true);
}

bool GetIntermediateData(bool bVariance, double* pdGamma,EMethod eMethod,  bool bE0_Only)
{
	bool bSuccess=true;

	for (int j = 0; j < m_iNumberOfDeathTime && bSuccess; j++)
	{
		bSuccess = GetE0AndE1(bVariance, j, pdGamma, eMethod, bE0_Only);
	}

	return bSuccess;
}


void Sort(double* pdArray, int iLength)
{
	double dTemp;
	for(int i=0; i<iLength; i++)
    {
		for(int j=i+1;j<iLength;j++)
		{
			if(pdArray[i]>pdArray[j])
			{
				dTemp=pdArray[i];
				pdArray[i]=pdArray[j];
				pdArray[j]=dTemp;
			}
		}
	}
}

void MultiSort(double* pdArray1, double* pdArray2, int iLength)
{
	double dTemp;
	for(int i=0; i<iLength; i++)
    {
		for(int j=i+1;j<iLength;j++)
		{
			if(pdArray1[i]>pdArray1[j])
			{
				dTemp=pdArray1[i];
				pdArray1[i]=pdArray1[j];
				pdArray1[j]=dTemp;

				dTemp=pdArray2[i];
				pdArray2[i]=pdArray2[j];
				pdArray2[j]=dTemp;
			}
		}
	}
}

void MultiSort(double* pdArray1, double* pdArray2, double*pdArray3, int iLength)
{
	double dTemp;
	for (int i = 0; i<iLength; i++)
	{
		for (int j = i + 1; j<iLength; j++)
		{
			if (pdArray1[i]>pdArray1[j])
			{
				dTemp = pdArray1[i];
				pdArray1[i] = pdArray1[j];
				pdArray1[j] = dTemp;

				dTemp = pdArray2[i];
				pdArray2[i] = pdArray2[j];
				pdArray2[j] = dTemp;

				dTemp = pdArray3[i];
				pdArray3[i] = pdArray3[j];
				pdArray3[j] = dTemp;
			}
		}
	}
}

void MultiSort(double* pdArray1, int* piArray2, int iLength)
{
	double dTemp;
	for(int i=0; i<iLength; i++)
    {
		for(int j=i+1;j<iLength;j++)
		{
			if(pdArray1[i]>pdArray1[j])
			{
				dTemp=pdArray1[i];
				pdArray1[i]=pdArray1[j];
				pdArray1[j]=dTemp;

				int iTemp=piArray2[i];
				piArray2[i]=piArray2[j];
				piArray2[j]=iTemp;
			}
		}
	}
}


double Mean(double* pdArray, int iBegin, int iEnd)
{
	assert(iBegin<=iEnd);
    
	double dTotal=0;
	for( int i=iBegin; i<=iEnd; i++)
	{
		dTotal+=pdArray[i];
	}
  
	double dMean=dTotal/(iEnd-iBegin+1);

	return(dMean);
}

double TotalSq(double* pdArray, int iBegin, int iEnd)
{
	double dTotalSq=0;
	for( int i=iBegin; i<=iEnd; i++)
	{
		dTotalSq+=pdArray[i]*pdArray[i];
	}
	return(dTotalSq);
}


int IsInCI(double dTrueParm, double dEstParm, double dSE,double dCriticalValue)
{
	int iAddedCount=0;
	bool bIsInCI=false;
	double dLow=dEstParm-dCriticalValue*dSE;
	double dHigh=dEstParm+dCriticalValue*dSE;

	if(dTrueParm>dLow && dTrueParm<dHigh)
		iAddedCount++;
	
	return(iAddedCount);
}

void GetVAndDeltaFromFile(FILE* fSurvival)
{
	int id=0;
	
	int iret=fseek(fSurvival,0,SEEK_SET);
	memset(m_piMaxCountOfObs,0,iSubjectNumber*sizeof(int));
	for(int i=0; i<iSubjectNumber; i++)
	{
		double time=0;
		int iCountOfObs[2];
		double alpha0=0, alpha1=0;
		
		fscanf(fSurvival,"%d %lf %d %d", 
			&id,&time,&m_piDelta[i],&iCountOfObs[0]);


		int iIndCov = iTrueTimeIndCov;
		for (int k = 0; k < iIndCov; k++)
			fscanf(fSurvival, "%lf", &m_pdZ[i][k]);

		
		if(m_piDelta[i]==0)
			m_cenRate++;
			
		m_id[i]=id;
		m_pdV[i]=time;
		for(int k=0; k<iTrueTimeDepCov;k++)
		{
			if(iTrueTimeDepCov==1)
			{
				m_piCountOfObs[i][k]=iCountOfObs[iCovUsed];
				for(int k=0; k<2;k++)
				{
					m_piMaxCountOfObs[i]=iCountOfObs[0];
				}
			}
			else
			{
			m_piCountOfObs[i][k]=iCountOfObs[k];
			if(iCountOfObs[k]>m_piMaxCountOfObs[i])
				m_piMaxCountOfObs[i]=iCountOfObs[k];
		
			}
			
		}

	}
}

void GetObservedCovariateBeforeEventFromFile(FILE* fLongitudinal)
{
	int iret=fseek(fLongitudinal,0,SEEK_SET);

	double dMaxObserveTimePlusOne=dMaxObserveTime+1;
	memset(m_pdObservedCovariate,0,iSubjectNumber*iObservations*iTimeDepCov);
	for(int i=0; i<iSubjectNumber; i++)
	{
		for(int j=0; j<iObservations;j++)
			m_pdObservedTime[i][j]=dMaxObserveTimePlusOne;
	}

	int idcov=0;
	int preid=-1;
	int id=0;
	for(int i=0; i<iSubjectNumber; i++)
	{
		int r=0;
		int m=0;
		for(int j=0;j<m_piMaxCountOfObs[i];j++)
		{
			m=r+j;
			double cov[2];
			
			double id0;
			fscanf(fLongitudinal,"%lf %lf %lf",&id0,&m_pdObservedTime[i][m],&cov[0]);
			id=(int)id0;

			if (iTrueTimeDepCov == 1)
			{
				m_pdObservedCovariate[i][0][m] = cov[iCovUsed];
			}
			else
			{
				m_pdObservedCovariate[i][0][m]=cov[0];
				m_pdObservedCovariate[i][1][m]=cov[1];
			}
#ifdef TIMEDEP_COV
			assert(m_pdObservedTime[i][m]>=0);
#endif
			if(id==preid)
				assert(false);
		}
			
		preid=id;
	}
}


bool IsEstimatesClose(double* dGamma1, double* dGamma0, double* dSd, double tolerance)
{
	bool bFound = true;

	for (int i = 0; i < iCov && bFound; i++)
	{
		if (fabs(dGamma1[i] - dGamma0[i]) > tolerance * dSd[i])
			bFound = false;
	}

	return(bFound);
}

bool IsSolutionFound(double* dGamma1,double* dGamma0, double tolerance)
{
	bool bFound=true;

	for(int i=0; i<iCov && bFound; i++)
	{
		//if(fabs(dGamma1[i]-dGamma0[i])>TOLERANCE*fabs(dGamma0[i]))
		if (fabs(dGamma1[i] - dGamma0[i])>tolerance*fabs(dGamma0[i]) || fabs(dGamma1[i])>1e20)
			bFound=false;
	}

	return(bFound);
}


bool IsIncludeSubject_Naive(int i)
{
	if(iTimeDepCov==0)
		return(true);

	bool bInclude=true;

	int m=0;
	
	for(int k=0; k<iTrueTimeDepCov && bInclude; k++)
	{
		if(!IsIncludeForCovariate_k_Naive(i,k,m))
			bInclude=false;
	}
	return(bInclude);
}


// j: the jth death time;
// k: the kth covariate;
// m: begin of the kth observation;
// i: the ith subject
bool IsIncludeForCovariate_k_Naive(int i,int k, int m)
{
	int iCount=0;
	if(m_piCountOfObs[i][k]>0)
	{
			iCount++;
	}
	else
		return(false);

	m++;
	int r=1;
	while(r<m_piCountOfObs[i][k] && iCount<Dim_MixedModel) 
	{
		if(Order_MixedModel>0)
		{
			if(m_pdObservedTime[i][m]-m_pdObservedTime[i][m-1]>1.0e-10)
				iCount++;
		}
		else
			iCount++;
		m++;
		r++;
	}

	if(iCount<Dim_MixedModel)
		return(false);
	else
		return(true);
		
}




void SetStartParametersForIteration(double *dGamma)
{
	for(int i=0; i<iCov; i++)
	{
		m_dStartGamma[i]=dGamma[i];
	}
}


void SortAllDeathTime()
{
	Sort(m_pdAllDeathTimes,m_iAllDeathNumber);
}


double GetCensoringRate()
{
	return m_cenRate;
}

double GetAveObs()
{
	return m_aveObs;
}

void GetMedianT()
{
	double* tempT=new double[m_iSubjectNumber];
	int j=0;
	for(int i=0; i<m_iSubjectNumber; i++)
	{
		if(m_piDelta[i]==1)
			tempT[j++]=m_pdV[i];
	}

	
	Sort(tempT,j);
	for(int r=0; r<19; r++)
	{
		m_qt[r] = tempT[j*(r+1)/20];
		m_qt_total[r] += tempT[j*(r+1)/20];
	}

	delete []tempT;
}

void GetMedianT_Risk()
{
	double* tempT = new double[m_iSubjectNumber];
	int j = 0;
	
	m_iNumberOfDeathTime_Naive = 0;
	m_iNumberOfSubject_AtRisk = 0;

	for (int i = 0; i<m_iSubjectNumber; i++)
	{
		if (IsIncludeSubject_Naive(i))
		{
			m_iNumberOfSubject_AtRisk++;
			if (m_piDelta[i] == 1)
			{
				tempT[j++] = m_pdV[i];
				m_iNumberOfDeathTime_Naive ++;
			}
		}
	}

	for (int r = 1; r < iRiskSet; r++)
	{
		m_qtRisk[r] = m_pdV[iSubjectNumber * r / iRiskSet-1];
	}
	m_qtRisk[iRiskSet] = m_pdV[iSubjectNumber - 1];

	m_dMedianT = tempT[j/2];
	return;
}


void SetInitiateParameters()
{
	double dStart[]={1,0,0,0};
	SetStartParametersForIteration(dStart);
	
	memset(m_dSigmaSq,0,PARM_SIGMA*sizeof(double));
	memset(m_dSigmaSqHat,0,PARM_SIGMA*sizeof(double));
	memset(m_dfCov,0,PARM_SIGMA*sizeof(double));

	memset(m_pdAlpha_Var, 0, iSubjectNumber*iTrueTimeDepCov*Dim_MixedModel*Dim_MixedModel*sizeof(double));

	memset(m_pdTheta, 0, m_iSubjectNumber*iDeathTime*DIM_TIMEDEP*DIM_TIMEDEP*sizeof(double));

	memset(m_maxVar, 0, iTrueTimeDepCov*sizeof(double));
	m_iCountVar = 0;
}

 
void GetMeanStandardDeviation(double& mean, double &sd, double* x, int m)
{
	double x_total = 0;
	double x2_total = 0;
	for (int i = 0; i < m; i++)
	{
		x_total += x[i];
		x2_total += x[i] * x[i];
	}
	mean = x_total / m;
	sd = sqrt((x2_total - x_total * x_total / m) / (m - 1));
}


double CrossValidationForBandWidth(int& iSelectedConstant, bool bCV, double dAveObsQ, int &iDeathNumber, int &iRiskNumber, double &dVar_t0, double &dVar_tm)
{
	if (SmoothParm_Iter_CV == 0 || !bCV)
	{
		int index[iSubjectNumber];
		GetSample(index, iSubjectNumber, iSubjectNumber);
		return(0);
	}
	
	int iStartMethod_CV = 0;
	EMethod eMethod[]={
		Naive,		
		SCS
	};
	const int iMethod = 2;
	double hSelected[iMethod];
	memset(hSelected, 0, iMethod*sizeof(double));

	int tempSubjectNumber = m_iSubjectNumber;
	double *tempV;
	int *tempDelta;
	double (*tempZ)[DIM_TIMEIND];
	CMyPoint (*tempAlpha)[DIM_TIMEDEP];
	int (*tempCountOfObs)[DIM_TIMEDEP];
	double (*tempObservedCovariate)[DIM_TIMEDEP][iObservations];
	double (*tempObservedTime)[iObservations];
	int iTempNumberOfDeathTime[iMethod][CV_FOLDS];

	double *testV;
	int *testDelta;
	double (*testZ)[DIM_TIMEIND];
	CMyPoint (*testAlpha)[DIM_TIMEDEP];
	int (*testCountOfObs)[DIM_TIMEDEP];
	double (*testObservedCovariate)[DIM_TIMEDEP][iObservations];
	double (*testObservedTime)[iObservations];
	int iTestNumberOfDeathTime[iMethod][CV_FOLDS];
	
	double *dAllSortedDeathTime;

	memset(iTempNumberOfDeathTime, 0, iMethod * CV_FOLDS * sizeof(int));
	memset(iTestNumberOfDeathTime, 0, iMethod * CV_FOLDS * sizeof(int));

	tempV=new double[iSubjectNumber];
	tempDelta=new int[iSubjectNumber];
	tempZ=new double[iSubjectNumber][DIM_TIMEIND];
	tempAlpha=new CMyPoint[iSubjectNumber][DIM_TIMEDEP];
	tempCountOfObs=new int[iSubjectNumber][DIM_TIMEDEP];
	tempObservedCovariate=new double[iSubjectNumber][DIM_TIMEDEP][iObservations];
	tempObservedTime=new double[iSubjectNumber][iObservations];

	testV=new double[iSubjectNumber];
	testDelta=new int[iSubjectNumber];
	testZ=new double[iSubjectNumber][DIM_TIMEIND];
	testAlpha=new CMyPoint[iSubjectNumber][DIM_TIMEDEP];
	testCountOfObs=new int[iSubjectNumber][DIM_TIMEDEP];
	testObservedCovariate=new double[iSubjectNumber][DIM_TIMEDEP][iObservations];
	testObservedTime=new double[iSubjectNumber][iObservations];
	testObservedTime = new double[iSubjectNumber][iObservations];

	dAllSortedDeathTime=new double[iDeathTime];

	double (*dTheta_Train)[iDeathTime];
	dTheta_Train=new double[iSubjectNumber][iDeathTime]; 

	InitiateForIterMethod(Naive);
	memcpy(dAllSortedDeathTime, m_pdSortedDeathTime, iDeathTime * sizeof(double));

	int index[iSubjectNumber];
	GetSample(index, iSubjectNumber,iSubjectNumber);


	// sort data according to index;
	for(int i=0; i<iSubjectNumber; i++)
    {
		tempV[i]=m_pdV[index[i]];
		tempDelta[i]=m_piDelta[index[i]];
        memcpy(&tempZ[i],&m_pdZ[index[i]],DIM_TIMEIND*sizeof(double));
		memcpy(&tempAlpha[i],&m_pcAlpha[index[i]], DIM_TIMEDEP *sizeof(CMyPoint));
		memcpy(&tempCountOfObs[i],&m_piCountOfObs[index[i]], DIM_TIMEDEP*sizeof(int));
		memcpy(&tempObservedCovariate[i],&m_pdObservedCovariate[index[i]], DIM_TIMEDEP*iObservations*sizeof(double));
		memcpy(&tempObservedTime[i],&m_pdObservedTime[index[i]], iObservations*sizeof(double));

		testV[i]=m_pdV[index[i]];
		testDelta[i]=m_piDelta[index[i]];
        memcpy(&testZ[i],&m_pdZ[index[i]],DIM_TIMEIND*sizeof(double));
		memcpy(&testAlpha[i],&m_pcAlpha[index[i]], DIM_TIMEDEP *sizeof(CMyPoint));
		memcpy(&testCountOfObs[i],&m_piCountOfObs[index[i]], DIM_TIMEDEP*sizeof(int));
		memcpy(&testObservedCovariate[i],&m_pdObservedCovariate[index[i]], DIM_TIMEDEP*iObservations*sizeof(double));
		memcpy(&testObservedTime[i],&m_pdObservedTime[index[i]], iObservations*sizeof(double));

	}


	// Compute Sigmahat;
	SetInitiateParameters();
	double dTemp_h = 0.01;
	GetG(Naive,dTemp_h, true);

	double dGamma_naive[iCov];
	double dGamma_se_naive[iCov];
	memset(dGamma_naive, 0, iCov * sizeof(double));
	memset(dGamma_se_naive, 0, iCov * sizeof(double));
	SetStartParametersForIteration(dGamma_naive);
	bool bSuccess = ProportionalHazardRegression(dGamma_naive, dGamma_se_naive, Naive, true, dTemp_h);

	double tempSigmaSqHat[PARM_SIGMA];     // Used to save the value ofSigmaSqHat
	GetSigmaHat();
	memcpy(tempSigmaSqHat,m_dSigmaSqHat,PARM_SIGMA*sizeof(double));

	
	iDeathNumber = 0;
	iRiskNumber = iSubjectNumber;
	dVar_t0 = 0;
	dVar_tm = 0;
	

	GetG(SCS, 0.01, true);
	double dGamma = 1;
	double dt_Smooth = GetSmoothParm(SCS, dAveObsQ, iDeathNumber, iRiskNumber, dVar_t0, dVar_tm, &dGamma);
		
	double mseSelected[iMethod];
	for(int k=0; k< iMethod; k++)
		mseSelected[k]=1e20;

	double pdGamma[iParm];
	memset(pdGamma, 0, iParm * sizeof(double));
	
	double mse[iMethod][SmoothParm_Iter_CV+1];
	memset(mse, 0, iMethod * (SmoothParm_Iter_CV+1) * sizeof(double));


	for (int h = 0; h < SmoothParm_Iter_CV; h++)
	{
		int k_Corr = 1;
		dTemp_h = dt_Smooth * (SmoothParm_Start + h * SmoothParm_Inc);
		memcpy(m_dSigmaSqHat, tempSigmaSqHat, PARM_SIGMA * sizeof(double));

		SetStartParametersForIteration(dGamma_naive);
		GetG(SCS, dTemp_h, true);
		double pdGammaSeCorr[iParm];
		memset(pdGammaSeCorr, 0, iParm * sizeof(double));
		bool bSuccess = ProportionalHazardRegression(pdGamma, pdGammaSeCorr, SCS, true, dTemp_h);


		if (bSuccess && pdGammaSeCorr[0] > dGamma_se_naive[0])
		{
			SetInitiateParameters();

			int iLength = iSubjectNumber / CV_FOLDS;
			int iRemainingLength = 0;


			m_iSubjectNumber = (CV_FOLDS - 1) * iLength;
			int tempSubjectNumber1 = m_iSubjectNumber;
			int iStart = m_iSubjectNumber;


			double dt = 1;


			for (int r = 0; r < CV_FOLDS; r++)
			{
		
				int iTestLength = iLength;
				if (r == 0)
					iTestLength = iSubjectNumber - (CV_FOLDS - 1) * iLength;


				memcpy(testV, &tempV[iStart], iTestLength * sizeof(double));
				memcpy(testDelta, &tempDelta[iStart], iTestLength * sizeof(int));
				memcpy(testZ, &tempZ[iStart], iTestLength * DIM_TIMEIND * sizeof(double));
				memcpy(testAlpha, &tempAlpha[iStart], iTestLength * DIM_TIMEDEP * sizeof(CMyPoint));
				memcpy(testCountOfObs, &tempCountOfObs[iStart], iTestLength * DIM_TIMEDEP * sizeof(int));
				memcpy(testObservedCovariate, &tempObservedCovariate[iStart], iTestLength * DIM_TIMEDEP * iObservations * sizeof(double));
				memcpy(testObservedTime, &tempObservedTime[iStart], iTestLength * iObservations * sizeof(double));


				for (int k = iStartMethod_CV; k < iMethod; k++)
				{
					memcpy(m_pdV, tempV, iSubjectNumber * sizeof(double));
					memcpy(m_piDelta, tempDelta, iSubjectNumber * sizeof(int));
					memcpy(m_pdZ, tempZ, iSubjectNumber* DIM_TIMEIND * sizeof(double));
					memcpy(m_pcAlpha, tempAlpha, iSubjectNumber* DIM_TIMEDEP * sizeof(CMyPoint));
					memcpy(m_piCountOfObs, tempCountOfObs, iSubjectNumber* DIM_TIMEDEP * sizeof(int));
					memcpy(m_pdObservedCovariate, tempObservedCovariate, iSubjectNumber* DIM_TIMEDEP* iObservations * sizeof(double));
					memcpy(m_pdObservedTime, tempObservedTime, iSubjectNumber* iObservations * sizeof(double));

					m_iSubjectNumber = iStart+iRemainingLength;
					if (iStart < m_iSubjectNumber)
					{
						memcpy(&m_pdV[iStart], &tempV[iStart + iLength], iRemainingLength * sizeof(double));
						memcpy(&m_piDelta[iStart], &tempDelta[iStart + iLength], iRemainingLength * sizeof(int));
						memcpy(&m_pdZ[iStart], &tempZ[iStart + iLength], iRemainingLength * DIM_TIMEIND * sizeof(double));
						memcpy(&m_pcAlpha[iStart], &tempAlpha[iStart + iLength], iRemainingLength * DIM_TIMEDEP * sizeof(CMyPoint));
						memcpy(&m_piCountOfObs[iStart], &tempCountOfObs[iStart + iLength], iRemainingLength * DIM_TIMEDEP * sizeof(int));
						memcpy(&m_pdObservedCovariate[iStart], &tempObservedCovariate[iStart + iLength], iRemainingLength * DIM_TIMEDEP * iObservations * sizeof(double));
						memcpy(&m_pdObservedTime[iStart], &tempObservedTime[iStart + iLength], iRemainingLength * iObservations * sizeof(double));
					}


			
					InitiateForIterMethod(eMethod[k]);
					memset(pdGamma, 0, iParm * sizeof(double));
					if (eMethod[k] == SCS)
					{
						memcpy(m_dSigmaSqHat, tempSigmaSqHat, PARM_SIGMA * sizeof(double));
					}

					double dE0_Train[iDeathTime];
					memset(dE0_Train, 0, iDeathTime * sizeof(double));

					memset(dTheta_Train, 0, iSubjectNumber * iDeathTime * sizeof(double));

					SetStartParametersForIteration(dGamma_naive);


					if (eMethod[k] == Naive)
						GetG(SCS, dTemp_h, true);
					else
					{
						GetG(eMethod[k], dTemp_h, true);
					}

					EMethod eMethodFit = eMethod[k];

					bool bSuccess = ProportionalHazardRegression(pdGamma, NULL, eMethodFit, false, dTemp_h);

					if (!bSuccess)
					{
						for (int s = 0; s < iParm; s++)
							pdGamma[s] = -9999;
					}

					m_iSubjectNumber = iTestLength;
					memcpy(m_pdV, testV, m_iSubjectNumber * sizeof(double));
					memcpy(m_piDelta, testDelta, m_iSubjectNumber * sizeof(int));
					memcpy(m_pdZ, testZ, m_iSubjectNumber * DIM_TIMEIND * sizeof(double));
					memcpy(m_pcAlpha, testAlpha, m_iSubjectNumber * DIM_TIMEDEP * sizeof(CMyPoint));
					memcpy(m_piCountOfObs, testCountOfObs, m_iSubjectNumber * DIM_TIMEDEP * sizeof(int));
					memcpy(m_pdObservedCovariate, testObservedCovariate, m_iSubjectNumber * DIM_TIMEDEP * iObservations * sizeof(double));
					memcpy(m_pdObservedTime, testObservedTime, m_iSubjectNumber * iObservations * sizeof(double));


					if (h == 0)
					{
						InitiateForIterMethod(eMethod[k]);
					}
					else
					{
						InitiateForIterMethod(eMethod[k]);
					}

					if (eMethod[k] == SCS)
					{
						memcpy(m_dSigmaSqHat, tempSigmaSqHat, PARM_SIGMA * sizeof(double));
					}

					EMethod eMethod_pl = eMethod[k];

					if (eMethod[k] == Naive)
					{
						eMethod_pl = SCS;
					}

					double dLike2 = 0;
					double dLike = -1e20;
					if (bSuccess && !isnan(pdGamma[0]))
					{
						GetG(eMethod_pl, dTemp_h, true);
							
						dLike = GetLogPartialLikelihood(pdGamma, eMethod[k]);

						if (isnan(dLike))
							dLike = -1e20;

					}
					mse[k][h] -= dLike;
				}

				iStart -= iLength;
				iRemainingLength += iTestLength;

			}

			for (int k = iStartMethod_CV; k < iMethod; k++)
			{
			
				if (mse[k][h] < mseSelected[k])
				{
					mseSelected[k] = mse[k][h];
					hSelected[k] = dTemp_h;
					if (eMethod[k] == SCS)
					{
						iSelectedConstant = h + 1;
					}
				}
			}
		}

		memcpy(m_pdV, tempV, iSubjectNumber * sizeof(double));
		memcpy(m_piDelta, tempDelta, iSubjectNumber * sizeof(int));
		memcpy(m_pdZ, tempZ, iSubjectNumber* DIM_TIMEIND * sizeof(double));
		memcpy(m_pcAlpha, tempAlpha, iSubjectNumber* DIM_TIMEDEP * sizeof(CMyPoint));
		memcpy(m_piCountOfObs, tempCountOfObs, iSubjectNumber* DIM_TIMEDEP * sizeof(int));
		memcpy(m_pdObservedCovariate, tempObservedCovariate, iSubjectNumber* DIM_TIMEDEP* iObservations * sizeof(double));
		memcpy(m_pdObservedTime, tempObservedTime, iSubjectNumber* iObservations * sizeof(double));
		m_iSubjectNumber = tempSubjectNumber;

		InitiateForIter_CV(SCS);
	}

	memcpy(m_pdV,tempV,iSubjectNumber*sizeof(double));
	memcpy(m_piDelta,tempDelta,iSubjectNumber*sizeof(int));
	memcpy(m_pdZ,tempZ,iSubjectNumber*DIM_TIMEIND*sizeof(double));
	memcpy(m_pcAlpha,tempAlpha,iSubjectNumber* DIM_TIMEDEP *sizeof(CMyPoint));
	memcpy(m_piCountOfObs, tempCountOfObs,iSubjectNumber*DIM_TIMEDEP*sizeof(int));
	memcpy(m_pdObservedCovariate, tempObservedCovariate,iSubjectNumber*DIM_TIMEDEP*iObservations*sizeof(double));
	memcpy(m_pdObservedTime,tempObservedTime, iSubjectNumber*iObservations*sizeof(double));
	m_iSubjectNumber = tempSubjectNumber;
	SortDataAccordingToV();
	InitiateForIter_CV(SCS);
	delete []tempV;
	delete []tempDelta;
	delete []tempZ;
	delete []tempAlpha;
	delete []tempCountOfObs;
	delete []tempObservedCovariate;
	delete []tempObservedTime;

	delete []testV;
	delete []testDelta;
	delete []testZ;
	delete []testAlpha;
	delete []testCountOfObs;
	delete []testObservedCovariate;
	delete []testObservedTime;
	delete []dAllSortedDeathTime;
	delete []dTheta_Train;

	return(hSelected[1]);
}


void Sort(int* pdArray, int iLength)
{
	int dTemp;
	for(int i=0; i<iLength; i++)
    {
		for(int j=i+1;j<iLength;j++)
		{
			if(pdArray[i]>pdArray[j])
			{
				dTemp=pdArray[i];
				pdArray[i]=pdArray[j];
				pdArray[j]=dTemp;
			}
		}
	}
}



void InitiateForIterMethod(EMethod eMethod)
{
	SortDataAccordingToV();
	GetSortedDeathTime(eMethod);
	GetNumberOfDeathBeforeEvent();
	
	double dTemp[iCov];
	memset(dTemp,0,iCov*sizeof(double));
	SetVarianceOfE(dTemp);
}

void InitiateForIter_CV(EMethod eMethod)
{
	GetSortedDeathTime(eMethod);
	GetNumberOfDeathBeforeEvent();

	double dTemp[iCov];
	memset(dTemp, 0, iCov*sizeof(double));
	SetVarianceOfE(dTemp);
}

void InitiateForIter()
{
	double dTemp[iCov];
	memset(dTemp, 0, iCov * sizeof(double));
	SetVarianceOfE(dTemp);
}

double GetLogPartialLikelihood(double* pdGamma, EMethod eMethod)
{

	double dE0_Test[iDeathTime];
	memset(dE0_Test, 0, iDeathTime*sizeof(double));


	double logLikelihood = 0;
	double dPreHaz = 0;
	double dS[iSubjectNumber];
	double dTotalS[iSubjectNumber];
	double dAdjust = 0.;
	memset(dS, 0, iSubjectNumber * sizeof(double));
	memset(dTotalS, 0, iSubjectNumber * sizeof(double));
	GetIntermediateData(false, pdGamma, eMethod, true);
	for (int j = 0; j<m_iNumberOfDeathTime; j++)
	{
		for (int i = 0; i<m_iSubjectNumber; i++)
		{
			if (IsDead(i, j))
			{
				for (int k = 0; k<iTimeDepCov; k++)
				{
					double Hijk = GetHijk(i, j, k, pdGamma, eMethod);
					double x = 0;

					logLikelihood += pdGamma[k] * Hijk;
				}
				for (int k = iTimeDepCov; k<iTimeDepCov + iTimeIndCov; k++)
				{
					logLikelihood += pdGamma[k] * m_pdG[i][j][k];
				}

			}
			
			if (IsAtRisk(i, j))
			{
				for (int k = 0; k < iTimeDepCov; k++)
				{
					double x = 0;
				}
			}
		}
		logLikelihood -= log(m_pdE0[j]);
	}
	return(logLikelihood);
}


void GetSample(int*sample, int n, int m)
{
	double* rannum=new double[n];
	int*  order=new int[n];
	imsls_d_random_uniform(n,IMSLS_RETURN_USER, rannum,0);
	GetOrder(sample,rannum,n); 

	delete []rannum;
	delete []order;
}


void GetOrder(int* order, double* pdArray, int iLength)
{
	double dTemp=0;
	int iTemp=0;
	for(int i=0; i<iLength;i++)
		order[i]=i;
	for(int i=0; i<iLength; i++)
    {
		for(int j=i+1;j<iLength;j++)
		{
			if(pdArray[i]>pdArray[j])
			{
				dTemp=pdArray[i];
				pdArray[i]=pdArray[j];
				pdArray[j]=dTemp;
				iTemp=order[i];
				order[i]=order[j];
				order[j]=iTemp;
			}
		}
	}
}


double GetSmoothParm(EMethod eMethod, double dAveObsQ, int& iDeathNumber, int& iRiskNumber, double& dVar_t0, double& dVar_tm, double* dGamma)
{
	double dSmoothParm=0;
	double dAlphaMean[Dim_MixedModel];
	double dAlphaVar[Dim_MixedModel * Dim_MixedModel];
	double dErrorVar=0;
	double dTempErrorVar[Dim_MixedModel * Dim_MixedModel];
	double dErrorVarRisk[Dim_MixedModel * Dim_MixedModel];


	memset(dAlphaMean, 0, Dim_MixedModel * sizeof(double));
	memset(dAlphaVar, 0, Dim_MixedModel * Dim_MixedModel * sizeof(double));
	memset(dTempErrorVar, 0,  Dim_MixedModel * Dim_MixedModel * sizeof(double));


	double t[Dim_MixedModel];
	memset(t, 0, Dim_MixedModel * sizeof(double));
	t[0] = 1;


	iDeathNumber = m_iNumberOfDeathTime_Naive;

	iRiskNumber = 0;

	for (int i = 0; i < iSubjectNumber; i++)
	{
		if (m_piIncludedDeathTime[i] < m_iNumberOfDeathTime)
		{

			SumMatrix(dTempErrorVar, dTempErrorVar, m_pdAlpha_Var[i][0], Dim_MixedModel, Dim_MixedModel);

			iRiskNumber++;
		}
	}

	Multiply(dErrorVarRisk, dTempErrorVar, t, Dim_MixedModel, Dim_MixedModel, 1);
	Multiply(&dErrorVar, t, dErrorVarRisk, 1, Dim_MixedModel, 1);

	dErrorVar /= iRiskNumber;

	memcpy(dAlphaVar, m_Alpha_Var_Hat[0][0], Dim_MixedModel * Dim_MixedModel * sizeof(double));
	Multiply(dAlphaMean, dAlphaVar, t, Dim_MixedModel, Dim_MixedModel, 1);
	Multiply(dAlphaMean, t, dAlphaMean, 1, Dim_MixedModel, 1);
	int itest = 0;

	double dC_Smooth = C_Smooth;

	if (SmoothParm_Iter_CV > 0)
		dC_Smooth *= 2.;

	dSmoothParm = sqrt(dErrorVar * dAlphaMean[0] / (dAlphaMean[0] + dErrorVar)) * dC_Smooth;
		 
	dVar_t0 = dErrorVar;
	dVar_tm = dErrorVar;
	return(dSmoothParm);
}


