#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <assert.h>
#include <math.h>
#include <memory.h>
#include <string.h>
#include <direct.h>
#include <time.h>
#include "MyType.h"
#include "MyExtern.h"
#include "MatrixExtern.h"

using namespace std;

void main(void)
{
	double dh = 0.01;
	
	time_t oldtime,newtime;
	time(&oldtime);

	char cName[iMaxNumberOfMethod][40];
	int r=0;
	strcpy(cName[r++],	   "Ideal:      ");	
	if (r < iNumberOfMethod)
	{
		strcpy(cName[r++], "Naive:      ");
	}
	if (r < iNumberOfMethod)
	{
		strcpy(cName[r++], "RC:         ");
		strcpy(cName[r++], "RRC:        ");
	}
	if (r < iNumberOfMethod)
	{
		strcpy(cName[r++], "SCS:        ");
	}

	EMethod eMethod[iMaxNumberOfMethod]={
		Ideal, 
		Naive,		
		RC,
		RRC,
		SCS,	
	};


	char cObsFileName[300] = "Obs.txt";
	char cResultFileName[300]="Result.txt";
	char cTemp[50];

		
	FILE* fResult=fopen(cResultFileName,"w");
	assert(fResult!=NULL);

	fprintf(fResult, "Method           h        ");
	for (int i = 0; i < iCov; i++)
	{
		fprintf(fResult, "Est%1d      se%1d         ", i+1,i+1);
	}
	fprintf(fResult, "\n");

	double dStartGamma[2*iCov];
	memset(dStartGamma,0,2*iCov*sizeof(double));

#ifdef ACTG
	dStartGamma[0] = -2;
#endif

    int iSimulationNumber=0;
	bool bMixedNormal=false;
		
	int iConvergedSimulation[iNumberOfMethod];    // the number of simulation that converges;
	//CCox cCox;
	double dTempGamma[iParmRegCal];   // Add parameters for the variance of alpha
	double dTempSeGamma[iParmRegCal];
	memset(dTempGamma, 0, (iParmRegCal)*sizeof(double));
	memset(dTempSeGamma, 0, (iParmRegCal) *sizeof(double));
	
	bool bSuccess=false;


	double dTotalGamma[iNumberOfMethod][iParmRegCal];
	memset(dTotalGamma, 0, iNumberOfMethod* (iParmRegCal) *sizeof(double));
	
	double dTotalGammaSq[iNumberOfMethod][iParmRegCal];
	memset(dTotalGammaSq, 0, iNumberOfMethod* (iParmRegCal) *sizeof(double));
	
	double dSdGammaHat[iNumberOfMethod][iParmRegCal];
	memset(dSdGammaHat, 0, iNumberOfMethod* (iParmRegCal) *sizeof(double));
	
	double dTotalSeGamma[iNumberOfMethod][iParmRegCal];
	memset(dTotalSeGamma, 0, iNumberOfMethod* (iParmRegCal) *sizeof(double));
	
	double (*pdGammaHat)[iMaxSimulation* (iParmRegCal)];
	double (*pdSeGammaHat)[iMaxSimulation* (iParmRegCal)];

	pdGammaHat=new double[iNumberOfMethod][iMaxSimulation* (iParmRegCal)];
	assert(pdGammaHat!=NULL);
	memset(pdGammaHat, 0, iNumberOfMethod*iMaxSimulation* (iParmRegCal) *sizeof(double));

	pdSeGammaHat=new double[iNumberOfMethod][iMaxSimulation* (iParmRegCal)];
	assert(pdSeGammaHat!=NULL);
	memset(pdSeGammaHat, 0, iNumberOfMethod*iMaxSimulation* (iParmRegCal) *sizeof(double));

	double dSubQ[iMaxSimulation];
	double dAveObs[iMaxSimulation];
	double dSdAveObs[iMaxSimulation];

	double dAveObsQ[iMaxSimulation];
	double dSdAveObsQ[iMaxSimulation];

	memset(dSubQ, 0, iMaxSimulation * sizeof(double));
	memset(dAveObs, 0, iMaxSimulation * sizeof(double));
	memset(dSdAveObs, 0, iMaxSimulation * sizeof(double));
	memset(dAveObsQ, 0, iMaxSimulation * sizeof(double));
	memset(dSdAveObsQ, 0, iMaxSimulation * sizeof(double));
	
	CCox();

	memset(iConvergedSimulation,0,iNumberOfMethod*sizeof(int));
	double mse[iNumberOfMethod][(iParmRegCal)];
	memset(mse,0,iNumberOfMethod* (iParmRegCal) *sizeof(double));
	int iAllConverged[iNumberOfMethod];
	memset(iAllConverged,0,iNumberOfMethod*sizeof(int));


	int iRiskNumber = iSubjectNumber;
	int iDeathNumber = 0;
	double dVar_t0 = 0;
	double dVar_tm = 0;

	int ns = 0;
	FILE* fSurvival=fopen(SURVFILE,"rt");
	FILE* fLongitudinal=fopen(LONGFILE,"rt");

	assert(fSurvival!=NULL);
	assert(fLongitudinal!=NULL);

	Initiate(fSurvival,fLongitudinal);

	fclose(fSurvival);
	fclose(fLongitudinal);

	double hSelected=0;
	int iSelectedConst=1;
	bool bCV = true;

	double dAveObsQCV = 1.;
	hSelected=CrossValidationForBandWidth(iSelectedConst, bCV, dAveObsQCV, iDeathNumber, iRiskNumber, dVar_t0, dVar_tm);
			
	InitiateForIter();
	SetInitiateParameters();

	cout << endl;
	for(int k=iStartMethod ;k<iNumberOfMethod;k++)
	{
		if(k>0 && eMethod[k-1] == Naive)
		{
			GetSigmaHat();
		}

		SetStartParametersForIteration(dStartGamma);

		if (eMethod[k] == SCS)
		{
			if (SmoothParm_Iter_CV == 0)
			{
				dh = 0.01;
				GetG(eMethod[k],  dh, true);
				dh = GetSmoothParm(eMethod[k], dAveObsQ[ns], iDeathNumber, iRiskNumber, dVar_t0, dVar_tm, pdGammaHat[3]);
			}
			else
				dh = hSelected;
		}
		else
		{
			dh = 0;
		}

		GetG(eMethod[k], dh, true);
						
		int kNaive = 1;
		if (eMethod[k] == SCS)
		{
			kNaive = 3;
		}
						
		if(eMethod[k]!=Ideal && eMethod[k] != Naive)
		{
			for (int m = 0; m < iCov; m++)
			{
				dStartGamma[m] = pdGammaHat[kNaive][iConvergedSimulation[kNaive] - 1 + m * iSimulationNumber];
			}
			SetStartParametersForIteration(dStartGamma);
		}

		bool bVar = true;

		memset(dTempGamma, 0, (iParmRegCal) *sizeof(double));
		memset(dTempSeGamma, 0, (iParmRegCal) * sizeof(double));
		bSuccess = ProportionalHazardRegression(dTempGamma, dTempSeGamma, eMethod[k], bVar, dh);
			
		if (bSuccess)
		{	
			// Save the estimates and standard error 
			for (int m = 0; m < (iParmRegCal); m++)
			{
				int r = iConvergedSimulation[k] + m*iSimulationNumber;
				if (eMethod[k] == SCS || eMethod[k] ==RC || m < iCov)
				{
					pdGammaHat[k][r] = dTempGamma[m];
					pdSeGammaHat[k][r] = dTempSeGamma[m];
				}
			}

			// Output the estimate and the standard error
			cout << cName[k] <<  " h=" << dh << " ";
			fprintf(fResult, "%s  %.5f  ", cName[k], dh);
			for (int m = 0; m < iCov; m++)
			{
				cout << "  Gamma[" << m+1 << "]=" << dTempGamma[m] << ",   SE[" << m+1 << "]=" << dTempSeGamma[m];
				fprintf(fResult, "%f %f ", dTempGamma[m], dTempSeGamma[m]);
			}
			cout << endl;
			fprintf(fResult, "\n");

			iConvergedSimulation[k]++;
		}
		else 
		{
			// ITERATION DOES NOT CONVERGE!;
			fprintf(fResult, "ITERATION DOES NOT CONVERGE! \n");
		}

		memset(dTempGamma, 0, (iParmRegCal) *sizeof(double));
		memset(dTempSeGamma, 0, (iParmRegCal) *sizeof(double));
	}
	cout << endl;
	fprintf(fResult,"\n");

	
	time(&newtime);
	//fprintf(fResult, "The running time is %d\n", newtime - oldtime);

	delete []pdGammaHat;
	delete []pdSeGammaHat;

	fclose(fResult);

	DeCCox();
} 