extern bool Inverse(double *pdInv, double* pA, int iDimension);
extern void Multiply(double* pdD, double* pdA, double* pdB,int m, int n, int r);
extern void MultiplyT(double* pdD, double* pdA, double* pdB,int m, int n, int r);
extern void TMultiply(double* pdD, double* pdA, double* pdB,int m, int n, int r);
extern void MultiplyScalar(double* pdD, double* pdA, double dB,int m, int n);
extern void SumMatrix(double* AB, double* A, double* B, int m, int n);
extern void SumMatrix(double* AB, double* A, const double* B, int m, int n);
extern void SubtractMatrix(double* AB, double* A, double* B, int m, int n);
