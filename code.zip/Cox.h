// Control.h: interface for the CCox class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONTROL_H__8D1D7986_81E5_11D4_BB9A_DEB49B6F773A__INCLUDED_)
#define AFX_CONTROL_H__8D1D7986_81E5_11D4_BB9A_DEB49B6F773A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

const int MAX_ITERATION=100;
const double TOLERANCE_CV_Naive = 1;
const double TOLERANCE=1.0e-5;
const double MIN_DOUBLE=1.0E-200;
const double MAX_DOUBLE=1.7E300;
const int INFO_NONSINGULAR=0;
const int INFO_GAMMA=1;
const int INFO_Eta=2;
const int INFO_ERROR=-1;



//class CCox  
//{
//private:
	int m_iSubjectNumber;		
	long m_lSeed;			 // seed for generate random numbers;
	double m_dMeanAlpha[4];  // mean of alpha: first two for trt 0, last two for trt 1;
	double m_dMeanCensor;
	double m_dTrueGamma[iCov]; // gamma=(gamma,eta);
	double m_dStartGamma[iCov];
	
	double m_dSigmaSq[PARM_SIGMA];   // variance of e_i
	double m_dSigmaSqHat[PARM_SIGMA];

	double *m_dTij;   // observation times;

	double* m_pdV;
	double* m_pdC;
	double* m_pdT;
	int* m_piDelta;
	double (*m_pdZ)[DIM_TIMEIND];  // time-independent covariates

	double (*m_pdG)[iDeathTime][iCov];
	double(*m_pdG_der)[iDeathTime][iCov];
	double(*m_pdG_der2)[iDeathTime][iCov];
	
	double* m_pdSortedDeathTime;
	int m_iNumberOfDeathTime;
	int m_iNumberOfDeathTime_Naive;  // count deaths with observations >= dim
	int m_iNumberOfSubject_AtRisk;   // count subjects with observations >= dim
	double m_dMedianT;               // Median of death times with observations >= dim
	int* m_piNumberOfDeathBeforeEvent;
	double (*m_pdObservedTime)[iObservations];       // tij;
	double (*m_pdObservedCovariate)[DIM_TIMEDEP][iObservations];  // W(tij);
	CMyPoint (*m_pcAlpha)[DIM_TIMEDEP];
	double(*m_pdAlpha_Var)[DIM_TIMEDEP][Dim_MixedModel*Dim_MixedModel];
	double m_Alpha_Var_Hat[iRiskSet][DIM_TIMEDEP][Dim_MixedModel * Dim_MixedModel];
	double m_Alpha_E_Hat[iRiskSet][DIM_TIMEDEP+1][iTrueTimeDepCov][Dim_MixedModel];
	double(*m_dXXInv)[DIM_TIMEDEP][Dim_MixedModel * Dim_MixedModel];
	double dTotalAlpha[iRiskSet][2][DIM_TIMEDEP][Dim_MixedModel];
	double dTotalAlpha2[iRiskSet][2][DIM_TIMEDEP][Dim_MixedModel * Dim_MixedModel];
	double dTotalFFInv[iRiskSet][DIM_TIMEDEP][Dim_MixedModel * Dim_MixedModel];
	int iIncludeSubject[iRiskSet][2];
	
	double (* m_pdTheta)[iDeathTime][DIM_TIMEDEP*DIM_TIMEDEP];
	int    *m_piIncludedDeathTime;  //m_puIncludedDeathTime[i]: the beginning death time that would include subject[i];
	                             
	double *m_pdE0;
	double (*m_pdE0_Tau)[iParmRegCal];
	double (*m_pdE1)[iCov];
	double (*m_pdE1_Tau)[iCov][iParmRegCal];
		
	double (*m_pdSSResidual)[DIM_TIMEDEP];
	int (*m_piCountOfObs)[DIM_TIMEDEP];
	int *m_piMaxCountOfObs;

	int *m_piNumberOfDeathAtDeathTime;
	int *m_piSubjectFailedAtDeathTime;

	double m_dfCov[PARM_SIGMA];
	int m_id[iSubjectNumber];

	int m_K;
	int m_numOfParmInPoly;

	double* m_D;
	double m_R[3];
	double m_mu[2];

	double (*m_pdTotalCumHazard)[iNumberOfMethod];
	double *m_pdAllDeathTimes;
	int m_iAllDeathNumber;

	double m_dmatChol[(iTrueTimeDepCov*Dim_MixedModel + iTrueTimeIndCov)*(iTrueTimeDepCov*Dim_MixedModel + iTrueTimeIndCov)];
	double m_dmatChol_b[(iTrueTimeDepCov*Dim_MixedModel + iTrueTimeIndCov)*(iTrueTimeDepCov*Dim_MixedModel + iTrueTimeIndCov)];
	double m_dMu[iTrueTimeDepCov*Dim_MixedModel + iTrueTimeIndCov];

	double m_cenRate;

	double m_qt[19];	
	double m_qt_total[19];
	double m_qtRisk[iRiskSet+1];

	double m_dMixedSD;
	double m_dMixedMean;

	double m_aveObs;

	double m_maxVar[DIM_TIMEDEP];
	double m_iCountVar;
	
	void CCox();
	void DeCCox();

	void Initiate(FILE* fSurvival,FILE* fLongitudinal);
	void SetCoefficentOfProportionalHazardModel(double *dGamma);
	void SetObservationTime(double* dTij);
	void SetVarianceOfE(double* dSigmaSq);
	void SetStartParametersForInteration(double *dGamma);

	void SortDataAccordingToV();
	void GetSortedDeathTime(EMethod eMethod); 
	void GetNumberOfDeathBeforeEvent();
	void GetGi(EMethod eMethod, int i, double h, bool bSmooth);
	void GetIdealGi(int i);
	void GetNaiveGi(int i);
	void GetRegCalGi_Linear(int i, EMethod eMethod);
	void GetCorrScoreGi_Linear_Aug(int i, double h, EMethod eMethod, bool bSmooth);
	bool LinearRegression(CMyPoint* pcAlphaHat,double* pdSSResidual, double* varAlpha, double* pdY,double* pdX, int iCountOfObs, int & n, double* XX, bool bComputeVarAlpha);
	double GetSigmaHat();

	bool ProportionalHazardRegression(double* pdGamma, double* pdSeGamma, EMethod eMethod, bool bComputeSE, double h);

	
	void GetVAndDeltaFromFile(FILE* fSurvival);
	void GetObservedCovariateBeforeEventFromFile(FILE* fLongitudinal);
	
	inline void Exchange(double *a,double *b);
	inline void Exchange(int *a,int *b);
    

	void SortAllDeathTime();

//private:
    bool GetInformation(double* pcInformation, double* pdGamma, EMethod eMethod);
	bool GetInversedInformation(double* pdInverseInformation,double* pdInformation);
	bool GetPhi(double* pdGamma,double* pdPhi, EMethod eMethod);
	double GetHijk(int i, int j, int k, double* dGamma,EMethod eMethod);
	double GetHijk_Taum(int i, int j, int k, int m, double* dGamma,EMethod eMethod);
	bool GetE0iAndE1i(int i, int j, double& dE0ij, double* dE1ij, double* dGamma, EMethod eMethod);
	double GetE0i_Tau(int i,int j, int k, double dE0ij, double* dGamma,EMethod eMethod);
	bool GetE0AndE1(bool bVariance, int j, double* dGamma, EMethod eMethod, bool bE0_Only);
	bool GetE0AndE1All(bool bVariance, double *dGamma, EMethod eMethod);
	bool IsDead(int i,int j);
	bool IsAtRisk(int i,int j);
	int GetIndexOfIncludedDeathTime(int i,int j,int iOldIndex,int iCovInd);
	bool GetSE(double* pdGamma,double* pdSeGamma,EMethod eMethod);
	bool GetIntermediateData(bool bVariance, double* pdGamma, EMethod eMethod, bool bE0_Only);
	void Sort(double* pdArray, int iLength);
	void MultiSort(double* pdArray1, double* pdArray2,int iLength);
	void MultiSort(double* pdArray1, double* pdArray2, double*pdArray3, int iLength);
	void MultiSort(double* pdArray1, int* piArray2, int iLength);
	double Mean(double* pdArray, int iBegin, int iEnd);
	double TotalSq(double* pdArray, int iBegin, int iEnd);
	int IsInCI(double dTrueParm, double dEstParm, double dSE,double dCriticalValue);
	bool IsSolutionFound(double *dGamma1, double* dGamma0, double tolerance);
	void GetNewGamma(double* dGamma1,double* dGamma0,double* dPhi,double* dInverseInformation);
	bool GetSeForCondScore_Linear(double* pdSeGamma,double* pdGamma, EMethod eMethod);
	bool GetSeForOther(double* pdSeGamma,double* pdGamma,  EMethod eMethod);
	bool IsIncludeSubject_Naive(int i);
	
	bool IsIncludeForCovariate_k_Naive(int i,int k, int m);
	void SetStartParametersForIteration(double *dGamma);

	double GetCensoringRate();

	void GetMedianT();
	void SetInitiateParameters();

	double CrossValidationForBandWidth(int& iSelectedConstant, bool bCV, double dAveObsQ, int& iDeathNumber, int& iRiskNumber, double& dVar_t0, double& dVar_tm);
	void Sort(int* pdArray, int iLength);
	void InitiateForIter();
	void InitiateForIter_CV(EMethod eMethod);
	void InitiateForIterMethod(EMethod eMethod);
	void GetSample(int*sample, int n, int m);
	void GetOrder(int* order, double* pdArray, int iLength);

	double GetLogPartialLikelihood(double* pdGamma, EMethod eMethod);

	void GetG(EMethod eMethod, double h, bool bSmooth);

	double GetSmoothParm(EMethod eMethod, double dAveObsQ, int& iDeathNumber, int& iRiskNumber, double& dVar_t0, double& dVar_tm, double* dGamma);
	void GetMedianT_Risk();

	void GetVarAlpha();

	bool GetExpXbeta(int i, int j, double& dE0ij, double* dGamma, EMethod eMethod);

	void GetMeanStandardDeviation(double& mean, double& sd, double* x, int m);

//};

#endif // !defined(AFX_CONTROL_H__8D1D7986_81E5_11D4_BB9A_DEB49B6F773A__INCLUDED_)
